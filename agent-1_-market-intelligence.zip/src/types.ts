export type ViewState = 
  | 'dashboard' 
  | 'ecosystem' 
  | 'competitor' 
  | 'decision' 
  | 'data-integration' 
  | 'regulatory'
  | 'presentation'
  | 'agent-query';

export interface TAMDataPoint {
  year: string;
  defiTAM: number;
  tradfiTAM: number;
  total: number;
}

export interface FlowDataPoint {
  month: string;
  rwaFlows: number;
  stablecoinFlows: number;
  indexFlows: number;
}

export interface EcosystemCategory {
  id: string;
  title: string;
  description: string;
  examples: string[];
}
