import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import { ViewState } from './types';
import DashboardView from './components/views/DashboardView';
import EcosystemView from './components/views/EcosystemView';
import CompetitorView from './components/views/CompetitorView';
import DecisionView from './components/views/DecisionView';
import DataIntegrationView from './components/views/DataIntegrationView';
import RegulatoryView from './components/views/RegulatoryView';
import PresentationView from './components/views/PresentationView';
import AgentQueryView from './components/views/AgentQueryView';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('agent-query');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardView />;
      case 'ecosystem': return <EcosystemView />;
      case 'competitor': return <CompetitorView />;
      case 'decision': return <DecisionView />;
      case 'data-integration': return <DataIntegrationView />;
      case 'regulatory': return <RegulatoryView />;
      case 'presentation': return <PresentationView />;
      case 'agent-query': return <AgentQueryView />;
      default: return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden text-slate-900 font-sans">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 h-full overflow-y-auto p-6 lg:p-10">
        <div className="max-w-7xl mx-auto flex flex-col gap-6">
          {renderView()}
        </div>
      </main>
    </div>
  );
}
