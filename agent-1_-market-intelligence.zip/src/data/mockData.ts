import { TAMDataPoint, FlowDataPoint, EcosystemCategory } from '../types';

export const tamForecastData: TAMDataPoint[] = [
  { year: 'Today', defiTAM: 105, tradfiTAM: 45, total: 150 },
  { year: '1 Yr', defiTAM: 140, tradfiTAM: 120, total: 260 },
  { year: '3 Yrs', defiTAM: 350, tradfiTAM: 800, total: 1150 },
  { year: '5 Yrs', defiTAM: 800, tradfiTAM: 3200, total: 4000 },
  { year: '10 Yrs', defiTAM: 2500, tradfiTAM: 13500, total: 16000 },
];

export const flowData: FlowDataPoint[] = [
  { month: 'Jan', rwaFlows: 1.2, stablecoinFlows: 15.0, indexFlows: 0.1 },
  { month: 'Feb', rwaFlows: 1.8, stablecoinFlows: 16.2, indexFlows: 0.15 },
  { month: 'Mar', rwaFlows: 2.5, stablecoinFlows: 18.1, indexFlows: 0.2 },
  { month: 'Apr', rwaFlows: 4.1, stablecoinFlows: 17.5, indexFlows: 0.35 },
  { month: 'May', rwaFlows: 5.6, stablecoinFlows: 22.0, indexFlows: 0.8 },
  { month: 'Jun', rwaFlows: 8.2, stablecoinFlows: 26.4, indexFlows: 1.5 },
];

export const ecosystemCategories: EcosystemCategory[] = [
  {
    id: 'base-layers',
    title: 'Base Layers / Infra',
    description: 'Foundational blockchains, bridging, and custody.',
    examples: ['L1/L2 chains', 'bridges', 'oracles', 'MPC/custody tech'],
  },
  {
    id: 'assets',
    title: 'Assets',
    description: 'Underlying tokens and tokenized representations.',
    examples: ['stablecoins', 'LST/LRT', 'RWAs (bonds, funds, credit, commodities)', 'tokenized equities', 'tokenized indices'],
  },
  {
    id: 'venues',
    title: 'Venues',
    description: 'Execution and trading environments.',
    examples: ['DEX (spot)', 'perps', 'options', 'RFQ', 'CEX', 'prime brokers'],
  },
  {
    id: 'credit',
    title: 'Credit',
    description: 'Lending and borrowing protocols.',
    examples: ['overcollateralized lending', 'undercollateralized (credit delegation)', 'structured credit/vaults'],
  },
  {
    id: 'issuance',
    title: 'Issuance & Compliance Rails',
    description: 'Infrastructure for compliant token generation.',
    examples: ['tokenization platforms', 'transfer agents', 'KYC/whitelist infra'],
  },
  {
    id: 'index-products',
    title: 'Index-Like Products',
    description: 'Structured products and automated strategies.',
    examples: ['on-chain indices', 'structured products', 'vault strategies'],
  },
  {
    id: 'data',
    title: 'Data & Analytics',
    description: 'Information providers covering risk and pricing.',
    examples: ['pricing/oracles', 'index calculation', 'proof-of-reserves', 'risk models'],
  },
  {
    id: 'tradfi',
    title: 'TradFi Rails',
    description: 'Traditional wrapper and distribution mechanisms.',
    examples: ['ETFs/ETNs', 'mutual funds', 'structured notes', 'custody', 'brokerage distribution'],
  },
];
