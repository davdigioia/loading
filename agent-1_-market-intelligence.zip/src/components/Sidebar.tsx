import React from 'react';
import { LayoutDashboard, Layers, Users, Lightbulb, Database, Scale, Presentation, MessageSquare } from 'lucide-react';
import { ViewState } from '../types';
import { cn } from '../lib/utils';

interface SidebarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
}

const navItems: { id: ViewState; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard & TAM', icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: 'ecosystem', label: 'Ecosystem Map', icon: <Layers className="w-5 h-5" /> },
  { id: 'competitor', label: 'Competitor Landscape', icon: <Users className="w-5 h-5" /> },
  { id: 'decision', label: 'Decision Support', icon: <Lightbulb className="w-5 h-5" /> },
  { id: 'data-integration', label: 'Data Triggers', icon: <Database className="w-5 h-5" /> },
  { id: 'regulatory', label: 'Regulatory Risk', icon: <Scale className="w-5 h-5" /> },
  { id: 'presentation', label: 'C-Suite Deck', icon: <Presentation className="w-5 h-5" /> },
  { id: 'agent-query', label: 'Agent Query (LLM)', icon: <MessageSquare className="w-5 h-5" /> },
];

export default function Sidebar({ currentView, onViewChange }: SidebarProps) {
  return (
    <div className="w-64 bg-slate-900 border-r border-slate-200 shadow-md flex flex-col h-screen text-slate-300">
      <div className="p-6 border-b border-slate-800 bg-slate-950">
        <div className="flex flex-col mb-4">
           <span className="text-[10px] tracking-[0.1em] text-red-500 font-bold uppercase mb-1">Intelligence Layer</span>
           <h1 className="font-bold tracking-tight text-white text-xl leading-snug">S&P DJI Agent:<br/>Market Synthesis</h1>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-3">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={cn(
                "w-full flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                currentView === item.id 
                  ? "bg-red-600 text-white shadow-sm" 
                  : "text-slate-300 hover:bg-slate-800 hover:text-white"
              )}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
