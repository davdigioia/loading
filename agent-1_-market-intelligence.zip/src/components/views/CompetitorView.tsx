import React, { useState } from 'react';
import { Target, Users, Search, AlertCircle, Loader2, X } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function CompetitorView() {
  const [dossierState, setDossierState] = useState<{ loading: boolean; data: string | null; competitor: string | null }>({ loading: false, data: null, competitor: null });

  const competitors = [
    { company: 'CF Benchmarks', focus: 'Crypto pricing, rates, RWA indices', threatLevel: 'High', partnerships: ['CME Group', 'Kraken'] },
    { company: 'MSCI', focus: 'Digital asset indexes, TradFi risk models', threatLevel: 'Medium', partnerships: ['Coinbase', 'Menai'] },
    { company: 'FTSE Russell', focus: 'Crypto asset index framework', threatLevel: 'Medium', partnerships: ['Digital Asset Research'] },
    { company: 'Bloomberg', focus: 'Galaxy crypto indices, data terminals', threatLevel: 'High', partnerships: ['Galaxy Digital'] },
    { company: 'Protocol-Native (e.g. Index Coop)', focus: 'On-chain structured products, yield vaults', threatLevel: 'Emerging', partnerships: ['Various DAOs', 'Aave'] },
  ];

  const handleGenerateDossier = async (competitor: string, context?: string) => {
    setDossierState({ loading: true, data: null, competitor });
    try {
      const resp = await fetch('/api/generate-dossier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ competitor, context })
      });
      if (!resp.ok) {
        throw new Error("Failed to generate dossier");
      }
      const data = await resp.json();
      setDossierState({ loading: false, data: data.dossier, competitor });
    } catch (e: any) {
      setDossierState({ loading: false, data: "Error generating dossier: " + e.message, competitor });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Threat Analysis</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">Competitor Landscape</h2>
        <p className="text-sm text-slate-600">Analyzing positioning of benchmark providers and data vendors.</p>
      </div>

      {dossierState.competitor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col relative rounded-md shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-slate-200">
               <h3 className="text-lg font-bold text-blue-900">AI Dossier: {dossierState.competitor}</h3>
               <button onClick={() => setDossierState({ loading: false, data: null, competitor: null })} className="text-slate-500 hover:text-slate-900 transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              {dossierState.loading ? (
                <div className="flex flex-col items-center justify-center h-64 space-y-4">
                  <span className="text-red-600 font-bold text-sm uppercase tracking-widest flex items-center">
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Synthesizing data...
                  </span>
                  <p className="text-xs text-slate-500">Querying real-time web and recent crypto activity for {dossierState.competitor}...</p>
                </div>
              ) : (
                <div className="prose prose-slate max-w-none prose-sm leading-relaxed">
                  <Markdown remarkPlugins={[remarkGfm]}>{dossierState.data}</Markdown>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="font-bold uppercase tracking-widest text-xs text-slate-600 flex items-center">
                <Target className="w-4 h-4 mr-2 text-red-600" /> Target Profiles
              </h3>
            </div>
            <div className="divide-y divide-slate-100">
              {competitors.map((comp, idx) => (
                <div key={idx} className="p-6 hover:bg-slate-50 transition-colors group">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-blue-900 text-lg">{comp.company}</h4>
                    <span className={`px-2.5 py-1 text-[10px] font-bold tracking-widest uppercase rounded-full ${
                      comp.threatLevel === 'High' ? 'text-red-700 bg-red-100' :
                      comp.threatLevel === 'Medium' ? 'text-amber-700 bg-amber-100' :
                      'text-blue-700 bg-blue-100'
                    }`}>
                      {comp.threatLevel} Threat
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-4">{comp.focus}</p>
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Key Partnerships</span>
                      <div className="flex gap-2">
                        {comp.partnerships.map((p, i) => (
                          <span key={i} className="px-2 py-1 bg-slate-100 text-[10px] font-bold text-slate-600 rounded-sm">{p}</span>
                        ))}
                      </div>
                    </div>
                    <button 
                      onClick={() => handleGenerateDossier(comp.company, "General overview of crypto offerings.")}
                      className="bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold px-4 py-2 rounded-sm transition-colors shadow-sm"
                    >
                      Generate AI Dossier
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6 relative overflow-hidden">
            <h3 className="font-bold text-blue-900 uppercase tracking-tight text-sm mb-3 flex items-center z-10 relative">
               White Space Analysis
            </h3>
            <p className="text-sm text-slate-600 mb-6 z-10 relative">
              Where can S&P DJI differentiate in the current ecosystem?
            </p>
            <ul className="space-y-5 z-10 relative text-sm">
              <li className="flex items-start">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5"></div>
                <div>
                  <strong className="block text-blue-900 text-sm tracking-tight mb-0.5">Regulated RWA Indices</strong>
                  <span className="text-slate-600 text-xs">Bringing standard institutional rigor to tokenized treasuries and credit.</span>
                </div>
              </li>
              <li className="flex items-start">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5"></div>
                <div>
                  <strong className="block text-blue-900 text-sm tracking-tight mb-0.5">Cross-Chain Benchmarks</strong>
                  <span className="text-slate-600 text-xs">Neutral pricing bridging multiple L1/L2 liquidity venues.</span>
                </div>
              </li>
              <li className="flex items-start">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5"></div>
                <div>
                  <strong className="block text-blue-900 text-sm tracking-tight mb-0.5">Validator Yield Ratings</strong>
                  <span className="text-slate-600 text-xs">Standardized index components for LST/LRT strategies.</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
