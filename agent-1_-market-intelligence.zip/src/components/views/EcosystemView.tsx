import React from 'react';
import { ecosystemCategories } from '../../data/mockData';
import { Database, Network, Building2, Coins, ArrowRightLeft, ScrollText, Layers, LineChart } from 'lucide-react';

const icons: Record<string, React.ReactNode> = {
  'base-layers': <Database className="w-5 h-5" />,
  'assets': <Coins className="w-5 h-5" />,
  'venues': <ArrowRightLeft className="w-5 h-5" />,
  'credit': <Building2 className="w-5 h-5" />,
  'issuance': <ScrollText className="w-5 h-5" />,
  'index-products': <Layers className="w-5 h-5" />,
  'data': <LineChart className="w-5 h-5" />,
  'tradfi': <Network className="w-5 h-5" />
};

export default function EcosystemView() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end mb-6">
        <div>
          <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Taxonomy</span>
          <h2 className="text-2xl font-black font-sans tracking-tight uppercase text-blue-900 mb-1">Ecosystem Mapping</h2>
          <p className="text-sm text-slate-600">Structural breakdown of all interconnected market disciplines.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {ecosystemCategories.map((cat) => (
          <div key={cat.id} className="group bg-white border border-slate-200 hover:border-blue-500 transition-all rounded-md p-5 shadow-sm">
            <div className="flex items-center space-x-3 mb-4">
              <div className="text-blue-600 group-hover:text-blue-800 transition-colors">
                {icons[cat.id]}
              </div>
              <h3 className="font-bold uppercase tracking-tight text-blue-900">{cat.title}</h3>
            </div>
            
            <p className="text-xs text-slate-600 mb-4 h-10">{cat.description}</p>
            
            <div className="pt-4 border-t border-slate-100">
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Key Areas</p>
              <ul className="space-y-2">
                {cat.examples.map((ex, i) => (
                  <li key={i} className="flex items-start text-[11px] font-bold text-slate-700">
                    <span className="text-red-500 mr-2 flex-shrink-0">{'//'}</span>
                    <span>{ex}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
