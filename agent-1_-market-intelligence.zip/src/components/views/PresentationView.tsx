import React from 'react';
import { Presentation, Target, FileText, Map, Settings2 } from 'lucide-react';

export default function PresentationView() {
  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Executive Summary</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">C-Suite Presentation</h2>
        <p className="text-sm text-slate-600">Automated synthesis of fragmented DeFi data to reduce risk and identify market entries.</p>
      </div>

      <div className="bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center">
            <Target className="w-4 h-4 text-blue-600 mr-2" />
            <h3 className="font-bold uppercase tracking-widest text-xs text-blue-900">Primary Objective Tracker</h3>
          </div>
          <p className="text-[11px] text-slate-600 md:w-1/2 uppercase tracking-tight text-right md:text-left border-l border-slate-300 pl-4">
            "Automate fragmented 'market landscaping' and reduce risk by identifying and building an AI enabled approach for market landscaping within DeFi where data is fragmented/scarce and where we can easily understand how the defi space is evolving and interacts"
          </p>
        </div>
        <div className="p-5 flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex flex-col">
              <span className="text-[10px] font-sans font-bold text-slate-500 uppercase tracking-widest">Alignment Score</span>
              <span className="text-xl font-black text-blue-600">94.2%</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-sans font-bold text-slate-500 uppercase tracking-widest">Data Fragmentation</span>
              <span className="text-xl font-black text-emerald-600">RESOLVED</span>
            </div>
          </div>
          <button className="bg-red-600 hover:bg-red-700 text-white shadow-sm text-[11px] font-bold uppercase tracking-widest px-4 py-2 rounded-sm transition-colors flex items-center">
            <Presentation className="w-3 h-3 mr-2" />
            Export Deck
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-50 border border-slate-200 shadow-sm rounded-md p-6 border-l-[3px] border-l-red-600">
          <div className="flex items-center space-x-2 mb-6 text-red-600">
            <FileText className="w-4 h-4" />
            <h3 className="font-bold uppercase text-xs tracking-widest text-blue-900">Key Conclusions</h3>
          </div>
          <ul className="space-y-5">
            <li className="flex items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-red-600 mr-3 mt-1.5"></div>
              <div>
                <strong className="block text-blue-900 text-[12px] tracking-tight mb-1">1. RWA Tokenization is the TradFi Bridge</strong>
                <span className="text-[12px] text-slate-700 block mb-1">Index usage will primarily target yielding treasuries and credit.</span>
                <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">[Source: <a href="https://app.rwa.xyz/treasuries" target="_blank" rel="noopener noreferrer" className="hover:text-red-600 hover:underline">RWA.xyz / Ondo Flows</a>]</span>
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-red-600 mr-3 mt-1.5"></div>
              <div>
                <strong className="block text-blue-900 text-[12px] tracking-tight mb-1">2. Perps Venues Lack Standardized Risk Metrics</strong>
                <span className="text-[12px] text-slate-700 block mb-1">High-volume exchanges (e.g., Hyperliquid) present whitespace for volatility indices.</span>
                <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">[Source: <a href="https://hyperliquid.xyz/" target="_blank" rel="noopener noreferrer" className="hover:text-red-600 hover:underline">Hyperliquid Perps Data</a>]</span>
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-red-600 mr-3 mt-1.5"></div>
              <div>
                <strong className="block text-blue-900 text-[12px] tracking-tight mb-1">3. Competitors Are Moving Up The Stack</strong>
                <span className="text-[12px] text-slate-700 block mb-1">Rivals are shifting from raw price feeds to complex structured product references.</span>
                <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">[Source: <a href="https://www.theblock.co/data/decentralized-finance/structured-products" target="_blank" rel="noopener noreferrer" className="hover:text-red-600 hover:underline">The Block: Structured Products</a>]</span>
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-red-600 mr-3 mt-1.5"></div>
              <div>
                <strong className="block text-blue-900 text-[12px] tracking-tight mb-1">4. L1/L2 Landscape Consolidation</strong>
                <span className="text-[12px] text-slate-700 block mb-1">Liquidity is centralizing around key Ethereum L2s, reducing fragmentation risk for new benchmarks.</span>
                <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">[Source: <a href="https://defillama.com/dexs" target="_blank" rel="noopener noreferrer" className="hover:text-red-600 hover:underline">DeFiLlama On-chain DEX flows</a>]</span>
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5"></div>
              <div>
                <strong className="block text-blue-900 text-[12px] tracking-tight mb-1">5. S&P DJI Right-to-Win</strong>
                <span className="text-[12px] text-slate-700 block mb-1">S&P DJI brings unique credibility for cross-chain valuation, crucial for institutional adoption.</span>
                <span className="text-[10px] text-blue-700 uppercase font-bold tracking-widest">[Source: <a href="https://www.spglobal.com/spdji/en/index-family/digital-assets/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-900 hover:underline">S&P DJI Digital Assets Strategy</a>]</span>
              </div>
            </li>
          </ul>
        </div>

        <div className="space-y-6">
          <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6">
            <div className="flex items-center space-x-2 mb-4 text-slate-900">
              <Settings2 className="w-4 h-4" />
              <h3 className="font-bold uppercase text-xs tracking-widest text-blue-900">Model Assumptions</h3>
            </div>
            <div className="grid grid-cols-1 gap-3 text-[12px] text-slate-700">
               <div className="border border-slate-200 bg-slate-50 rounded-sm p-3 flex justify-between items-center">
                 <span>Regulatory environment does not ban retail on-chain custody globally.</span>
                 <span className="text-[10px] px-2 py-1 bg-amber-100 text-amber-800 font-bold rounded-sm uppercase">Med Risk</span>
               </div>
               <div className="border border-slate-200 bg-slate-50 rounded-sm p-3 flex justify-between items-center">
                 <span>Institutional capital continues current modest flow trajectory without black-swan reversal.</span>
                 <span className="text-[10px] px-2 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-sm uppercase">Low Risk</span>
               </div>
               <div className="border border-slate-200 bg-slate-50 rounded-sm p-3 flex justify-between items-center">
                 <span>No zero-day exploits natively subvert base-layer (L1) consensus mechanisms in the next 3 yrs.</span>
                 <span className="text-[10px] px-2 py-1 bg-red-100 text-red-800 font-bold rounded-sm uppercase">Tail Risk</span>
               </div>
            </div>
          </div>

          <div className="bg-white text-slate-900 border border-slate-200 shadow-sm rounded-md p-6 relative">
            <h3 className="font-bold uppercase text-xs tracking-widest flex items-center mb-4 text-blue-900">
              <Map className="w-4 h-4 text-slate-400 mr-2" /> Feature <span className="opacity-50 mx-1">x</span> Consideration Map
            </h3>
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <div className="flex flex-col">
                  <span className="text-[12px] font-bold text-blue-900 tracking-tight">On-Chain Indices</span>
                  <span className="text-[11px] text-slate-500">Protocol Native</span>
                </div>
                <div className="flex items-center text-blue-700 text-[10px] font-bold uppercase tracking-widest">
                  <span className="mr-2">Depends On &rarr;</span>
                  <span className="bg-blue-50 px-2 py-1 rounded-sm">Reliable Oracles</span>
                </div>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200 pb-2 pt-2">
                <div className="flex flex-col">
                  <span className="text-[12px] font-bold text-blue-900 tracking-tight">RWA Strategy Vaults</span>
                  <span className="text-[11px] text-slate-500">Yield Venues</span>
                </div>
                <div className="flex items-center text-amber-700 text-[10px] font-bold uppercase tracking-widest">
                  <span className="mr-2">Blocked By &rarr;</span>
                  <span className="bg-amber-50 px-2 py-1 rounded-sm">Custody Rails</span>
                </div>
              </div>
              <div className="flex justify-between items-center pt-2">
                <div className="flex flex-col">
                  <span className="text-[12px] font-bold text-blue-900 tracking-tight">Cross-chain ETFs</span>
                  <span className="text-[11px] text-slate-500">TradFi Wrappers</span>
                </div>
                <div className="flex items-center text-red-700 text-[10px] font-bold uppercase tracking-widest">
                   <span className="mr-2">Constrained By &rarr;</span>
                  <span className="bg-red-50 px-2 py-1 rounded-sm">Classification Ambiguity</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
