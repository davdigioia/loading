import React, { useState, useEffect, useRef } from 'react';
import { Send, Terminal, Database, ArrowRight, Bot, User, Rss, Loader2 } from 'lucide-react';

import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  content: string;
  timestamp: string;
}

interface FeedLog {
  id: string;
  source: string;
  action: string;
  timestamp: string;
  status: 'success' | 'syncing' | 'pending';
  link?: string;
}

export default function AgentQueryView() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'agent',
      content: 'System Initialized. I am your specialized market landscaping agent. I am continuously monitoring DeFi data (RWA workflows, perps protocols, index products) against TradFi parameters. How can I assist with your market analysis today?',
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [feedLogs, setFeedLogs] = useState<FeedLog[]>([
    { id: '101', source: 'RWA.xyz', action: 'Ingested TVL changes across tokenized treasuries', timestamp: '14:21:00', status: 'success' },
    { id: '102', source: 'Hyperliquid API', action: 'Polled perps volumes & open interest rates', timestamp: '14:21:45', status: 'success' },
  ]);

  useEffect(() => {
    async function fetchLiveNews() {
      try {
        const response = await fetch('/api/live-data');
        if (!response.ok) throw new Error('Live data fetch failed');
        const data = await response.json();
        
        if (Array.isArray(data) && data.length > 0) {
          const newLogs = data.slice(0, 10).map((item, index) => ({
            id: `news-${index}-${Date.now()}`,
            source: item.source,
            action: item.title,
            timestamp: new Date(item.date).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
            status: 'success' as const,
            link: item.link
          }));
          
          setFeedLogs(prev => {
            const combined = [...newLogs, ...prev];
            // Remove duplicates by title
            const unique = combined.filter((v, i, a) => a.findIndex(t => (t.action === v.action)) === i);
            return unique.slice(0, 15);
          });
        }
      } catch (e) {
        console.error("Failed to load live data feed", e);
      }
    }
    
    // Initial fetch
    fetchLiveNews();
    
    // Poll every 60 seconds
    const interval = setInterval(fetchLiveNews, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newUserMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      const resp = await fetch('/api/agent-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: inputValue, history: messages.filter(m => m.id !== '1') })
      });
      if (!resp.ok) throw new Error("Failed");
      const data = await resp.json();
      
      const responseMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'agent',
        content: data.reply || "No response received.",
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, responseMsg]);
    } catch (e: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'agent',
        content: `Error connecting to AI: ${e.message}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-[80vh] flex gap-6">
      <div className="flex-1 flex flex-col min-w-0 bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
          <div className="flex items-center text-slate-900">
            <Terminal className="w-5 h-5 mr-3" />
            <h2 className="font-bold uppercase tracking-widest text-sm text-blue-900">Agent Query Console</h2>
          </div>
          <span className="text-[10px] font-bold tracking-widest uppercase bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
            Context: Global Defi/Tradfi Integration
          </span>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-md ${
                  msg.role === 'user' 
                    ? 'bg-slate-900 text-white ml-4' 
                    : 'bg-red-600 text-white mr-4'
                }`}>
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className="flex flex-col">
                  <div className={`mb-1 flex items-baseline ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
                      {msg.role === 'user' ? 'Analyst' : 'Agent Synthesis'} // {msg.timestamp}
                    </span>
                  </div>
                  <div className={`p-4 rounded-md ${
                    msg.role === 'user' 
                      ? 'bg-slate-100 text-slate-900 border border-slate-200' 
                      : 'bg-white text-slate-900 border border-slate-200 shadow-sm'
                  }`}>
                    {msg.role === 'agent' ? (
                      <div className="prose prose-slate max-w-none prose-sm leading-relaxed" style={{ fontSize: '13px' }}>
                        <Markdown remarkPlugins={[remarkGfm]}>{msg.content}</Markdown>
                      </div>
                    ) : (
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
               <div className="flex max-w-[80%] flex-row">
                 <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-md bg-red-600 text-white mr-4">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="flex items-center space-x-2 text-slate-500 bg-white p-4 border border-slate-200 rounded-md shadow-sm">
                  <span className="w-2 h-2 bg-red-600 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-2 h-2 bg-red-600 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-2 h-2 bg-red-600 rounded-full animate-bounce"></span>
                  <span className="text-[11px] font-bold uppercase tracking-widest ml-2">Synthesizing...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200">
          <form onSubmit={handleSendMessage} className="flex gap-4">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask the LLM to synthesize trends, map features, or compare specific competitor indices..."
              className="flex-1 bg-white border border-slate-300 rounded-sm focus:border-red-600 focus:outline-none focus:ring-1 focus:ring-red-600 text-slate-900 px-4 py-3 text-sm placeholder:text-slate-500 transition-colors shadow-sm"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 font-bold shadow-sm uppercase tracking-widest text-[11px] rounded-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
               Query <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </form>
        </div>
      </div>

      <div className="w-80 flex flex-col min-h-0 bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex flex-col justify-center">
           <h3 className="font-bold uppercase text-xs tracking-widest text-blue-900 flex items-center mb-1">
             <Rss className="w-4 h-4 text-blue-600 mr-2" /> Live Market Data
           </h3>
           <p className="text-[11px] text-slate-600 leading-tight">
             Automated scraping resolving fragmentation across DeFi protocols.
           </p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
          {feedLogs.map((log) => (
            <div key={log.id} className="border border-slate-200 p-3 bg-white rounded-md relative overflow-hidden group shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-bold uppercase tracking-widest text-blue-700">
                  {log.source}
                </span>
                <span className="text-[10px] font-mono text-slate-500">
                  {log.timestamp}
                </span>
              </div>
              {log.link ? (
                <a href={log.link} target="_blank" rel="noopener noreferrer" className="text-[12px] text-slate-700 leading-snug hover:text-blue-600 hover:underline block">
                  {log.action}
                </a>
              ) : (
                <p className="text-[12px] text-slate-700 leading-snug">
                  {log.action}
                </p>
              )}
              <div className="mt-2 flex items-center justify-end">
                {log.status === 'success' ? (
                  <span className="text-[10px] font-bold text-emerald-600 uppercase flex items-center">
                    <Database className="w-3 h-3 mr-1" /> Vectorized
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-amber-600 uppercase flex items-center">
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Ingesting
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
