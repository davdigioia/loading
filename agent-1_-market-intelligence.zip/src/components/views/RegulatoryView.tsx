import React from 'react';
import { Scale, Clock, ShieldAlert, FileSearch } from 'lucide-react';

export default function RegulatoryView() {
  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Risk Management</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">Regulatory & Risk Framework</h2>
        <p className="text-sm text-slate-600">Assessing ambiguities, timeline probabilities, and impact on S&P DJI.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center">
            <Scale className="w-4 h-4 text-red-600 mr-2" />
            <h3 className="font-bold uppercase tracking-widest text-xs text-blue-900">Current Ambiguities</h3>
          </div>
          <div className="p-5 space-y-4 text-xs font-sans">
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <strong className="text-[11px] tracking-tight uppercase text-red-700 font-bold block mb-1">Classification of LSTs</strong>
              <p className="text-slate-700 mt-1 leading-relaxed">Whether Liquid Staking Tokens are treated as securities or commodities directly affects if they can be included in a standard index without broker-dealer regulatory overrides.</p>
            </div>
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-md">
              <strong className="text-[11px] tracking-tight uppercase text-amber-700 font-bold block mb-1">Index Provider Liability for DeFi exploits</strong>
              <p className="text-slate-700 mt-1 leading-relaxed">If an on-chain index component (smart contract) is hacked, where does the liability fall for the benchmark administrator?</p>
            </div>
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
              <strong className="text-[11px] tracking-tight uppercase text-slate-700 font-bold block mb-1">Cross-jurisdictional rules</strong>
              <p className="text-slate-700 mt-1 leading-relaxed">MiCA establishes clear token guidelines in the EU, whilst SEC/CFTC remain fractured. Global indices will face bifurcation.</p>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center">
            <Clock className="w-4 h-4 text-blue-600 mr-2" />
            <h3 className="font-bold uppercase tracking-widest text-xs text-blue-900">Probable Timeline</h3>
          </div>
          <div className="p-5 flex flex-col items-start min-h-[300px]">
            <div className="relative pl-6 border-l-2 border-slate-200 pb-8 w-full">
              <span className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-blue-600"></span>
              <h4 className="font-bold tracking-tight uppercase text-[11px] text-blue-900 mb-1 mt-[-2px]">Short Term (1-3 yrs)</h4>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">Clarification on stablecoins. Growth in heavily permissioned RWA funds. Early ETF explorations for alternative L1s.</p>
            </div>
            <div className="relative pl-6 border-l-2 border-slate-200 pb-8 w-full">
              <span className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-amber-500"></span>
              <h4 className="font-bold tracking-tight uppercase text-[11px] text-blue-900 mb-1 mt-[-2px]">Mid Term (3-5 yrs)</h4>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">Establishment of clearing and settlement standards for tokenized equities. Defi/Tradfi integration bridges formally regulated.</p>
            </div>
            <div className="relative pl-6 border-l-2 border-transparent pb-0 w-full">
               <span className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-red-600"></span>
              <h4 className="font-bold tracking-tight uppercase text-[11px] text-blue-900 mb-1 mt-[-2px]">Long Term (5-10 yrs)</h4>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">Unified global taxonomy. Entire asset classes (fixed income, real estate) default to on-chain issuance.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
