import React, { useState } from 'react';
import { RefreshCw, Database, FileText, Globe, Key, Share2, UploadCloud, ChevronRight, ExternalLink } from 'lucide-react';

const integrationSources = [
  { name: 'Artemis Terminal', type: 'Flows / Market Data', status: 'Connected', icon: <Database />, link: 'https://www.artemis.xyz' },
  { name: 'Dune Analytics', type: 'On-chain Data', status: 'Connected', icon: <Database />, link: 'https://dune.com' },
  { name: 'Hyperliquid', type: 'On-chain Perps', status: 'Connected', icon: <Globe />, link: 'https://hyperliquid.xyz' },
  { name: 'RWA.xyz', type: 'Market Data', status: 'Connected', icon: <Database />, link: 'https://rwa.xyz' },
  { name: 'Ondo Finance', type: 'RWA Protocol', status: 'Active', icon: <Database /> },
  { name: 'Centrifuge', type: 'RWA Protocol', status: 'Connected', icon: <Database /> },
  { name: 'Securitize', type: 'RWA Issuance', status: 'Connected', icon: <Database /> },
  { name: 'Kraken', type: 'Centralized Exchange', status: 'Active', icon: <Database /> },
  { name: 'Robinhood', type: 'Brokerage / Flows', status: 'Active', icon: <Database /> },

  { name: 'CoinDesk', type: 'News & Stories', status: 'Active', icon: <Globe />, link: 'https://www.coindesk.com' },
  { name: 'The Block', type: 'News & Stories', status: 'Active', icon: <Globe />, link: 'https://www.theblock.co' },
  { name: 'PR Newswire', type: 'News & Stories', status: 'Active', icon: <FileText />, link: 'https://www.prnewswire.com' },
  { name: 'TradingView', type: 'Market Data', status: 'Active', icon: <Database />, link: 'https://www.tradingview.com' },
  { name: 'Ledger Insights', type: 'News & Stories', status: 'Active', icon: <Globe />, link: 'https://www.ledgerinsights.com' },
  { name: 'Crypto Insights', type: 'News & Stories', status: 'Active', icon: <Globe />, link: 'https://cryptoinsights.com' },
  { name: 'CNBC', type: 'News & Stories', status: 'Active', icon: <Globe />, link: 'https://www.cnbc.com' },
  { name: 'X', type: 'Social Media', status: 'Active', icon: <Share2 />, link: 'https://x.com' },

  { name: 'Outlook Attachments', type: 'Internal Workspace', status: 'Require Auth', icon: <FileText /> },
  { name: 'SharePoint Documents', type: 'Internal Workspace', status: 'Connected', icon: <Share2 /> },
  { name: 'Call Transcripts', type: 'Corporate Data', status: 'Connected', icon: <FileText /> },
  { name: 'Regulatory Sites', type: 'Drafts, Speeches, Opinions', status: 'Active', icon: <Key /> }
];

export default function DataIntegrationView() {
  const [pulling, setPulling] = useState<string | null>(null);

  const handlePull = (sourceName: string) => {
    setPulling(sourceName);
    setTimeout(() => {
      setPulling(null);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Data Pipeline</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">Agent Data Integrations</h2>
        <p className="text-sm text-slate-600">Review supported pipeline sources for web search generation and market data intelligence.</p>
      </div>

      <div className="bg-white border border-slate-200 shadow-sm rounded-md overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex justify-between items-center bg-slate-50">
          <h3 className="font-bold uppercase tracking-widest text-xs text-slate-600 flex items-center">
             Supported Sources & Endpoints
          </h3>
          <button className="text-[11px] bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-sm transition-colors flex items-center shadow-sm">
            <RefreshCw className="w-3 h-3 mr-2" /> Verify Connections
          </button>
        </div>
        
        <div className="divide-y divide-slate-100">
          {integrationSources.map((source, i) => (
            <div key={i} className="p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between hover:bg-slate-50 transition-colors">
              <div className="flex items-center space-x-4 w-full sm:w-auto">
                <div className="w-10 h-10 bg-slate-100 text-blue-700 flex items-center justify-center flex-shrink-0 rounded-md">
                  {React.cloneElement(source.icon as React.ReactElement, { className: 'w-5 h-5' })}
                </div>
                <div>
                  <h4 className="font-bold text-blue-900 flex items-center">
                    {source.name}
                    {source.link && (
                      <a href={source.link} target="_blank" rel="noopener noreferrer" className="ml-2 text-slate-400 hover:text-blue-600 transition-colors">
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </h4>
                  <p className="text-[11px] text-slate-500 font-medium uppercase tracking-widest mt-0.5">{source.type}</p>
                </div>
              </div>
              
              <div className="flex items-center w-full sm:w-auto justify-between sm:justify-end mt-4 sm:mt-0 space-x-4">
                <span className={`text-[10px] font-bold tracking-widest px-2.5 py-1 uppercase rounded-full ${
                  source.status === 'Connected' || source.status === 'Active' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'bg-amber-100 text-amber-700'
                }`}>
                  {source.status}
                </span>
                
                <button 
                  onClick={() => handlePull(source.name)}
                  disabled={pulling !== null || source.status === 'Require Auth'}
                  className="flex items-center text-[10px] uppercase font-bold tracking-widest text-slate-600 hover:text-blue-700 border border-slate-300 hover:border-blue-600 rounded-sm px-3 py-1.5 bg-white disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
                >
                  {pulling === source.name ? (
                    <><RefreshCw className="w-3 h-3 mr-2 animate-spin" /> Verifying...</>
                  ) : (
                    <><UploadCloud className="w-3 h-3 mr-2" /> Ping Source</>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6 overflow-hidden relative">
        <h3 className="font-bold uppercase text-xs tracking-widest mb-4 relative z-10 text-blue-900 border-b border-slate-200 pb-2">Data Pull Scheduling & Rules</h3>
        <ul className="space-y-4 text-sm text-slate-600 relative z-10 font-medium">
          <li className="flex items-start">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5 flex-shrink-0"></span>
            <div><strong className="text-blue-900 font-bold">Manual Triggers:</strong> Activate pulling on-demand; avoiding randomized/aggressive scraping.</div>
          </li>
          <li className="flex items-start">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5 flex-shrink-0"></span>
            <div><strong className="text-blue-900 font-bold">Event Triggers:</strong> Pull internal documents (Outlook/SharePoint) ON UPDATE, and respond conditionally to real-time market event triggers.</div>
          </li>
          <li className="flex items-start">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5 flex-shrink-0"></span>
            <div><strong className="text-blue-900 font-bold">Daily Jobs:</strong> Scrape X (Twitter), media outlets (CoinDesk, The Block, CNBC), and flow/terminal metrics (Artemis, Dune, Robinhood) on a daily cron.</div>
          </li>
          <li className="flex items-start">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5 flex-shrink-0"></span>
            <div><strong className="text-blue-900 font-bold">Weekly Jobs:</strong> Pull regulatory updates, drafted speeches, consultations, and Draft RTS weekly.</div>
          </li>
          <li className="flex items-start">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-3 mt-1.5 flex-shrink-0"></span>
            <div><strong className="text-blue-900 font-bold">Quarterly Jobs:</strong> Refresh static regulations, macro policy decisions, and comprehensive legal opinions.</div>
          </li>
        </ul>
      </div>
    </div>
  );
}
