import React, { useState, useMemo, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { tamForecastData } from '../../data/mockData';
import { TrendingUp, Activity, BarChart3, PieChart, Filter, Server } from 'lucide-react';

const historicalMarketData = [
  { month: 'Jul 25', RWA: 4.2, Stablecoins: 148.5, Indices: 0.12 },
  { month: 'Aug 25', RWA: 4.5, Stablecoins: 150.2, Indices: 0.15 },
  { month: 'Sep 25', RWA: 5.1, Stablecoins: 153.8, Indices: 0.16 },
  { month: 'Oct 25', RWA: 5.4, Stablecoins: 152.4, Indices: 0.19 },
  { month: 'Nov 25', RWA: 5.8, Stablecoins: 156.1, Indices: 0.22 },
  { month: 'Dec 25', RWA: 6.2, Stablecoins: 159.0, Indices: 0.25 },
  { month: 'Jan 26', RWA: 6.5, Stablecoins: 161.5, Indices: 0.28 },
  { month: 'Feb 26', RWA: 7.1, Stablecoins: 163.2, Indices: 0.32 },
  { month: 'Mar 26', RWA: 7.6, Stablecoins: 165.8, Indices: 0.38 },
  { month: 'Apr 26', RWA: 8.2, Stablecoins: 164.5, Indices: 0.41 },
  { month: 'May 26', RWA: 8.9, Stablecoins: 167.3, Indices: 0.45 },
  { month: 'Jun 26', RWA: 9.8, Stablecoins: 169.1, Indices: 0.52 },
];

export default function DashboardView() {
  const [timePeriod, setTimePeriod] = useState('YTD');
  const [assetClass, setAssetClass] = useState('All');

  const filteredData = useMemo(() => {
    let data = [...historicalMarketData];
    if (timePeriod === '3M') data = data.slice(-3);
    else if (timePeriod === '6M') data = data.slice(-6);
    else if (timePeriod === '1Y') data = data.slice(-12);
    else if (timePeriod === 'YTD') data = data.slice(-6); // Jan-Jun 26
    return data;
  }, [timePeriod]);

  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Overview</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">Market Projections</h2>
        <p className="text-sm text-slate-600">Synthesizing data from RWA, TradFi distributions, and DeFi on-chain activity.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { title: 'Total Crypto TVL', value: '$105B+', icon: <PieChart className="w-4 h-4 text-blue-700" />, source: 'DeFiLlama', href: 'https://defillama.com/' },
          { title: 'Proj 2030 Tokenized TAM', value: '$16 Trillion', icon: <TrendingUp className="w-4 h-4 text-blue-700" />, source: 'BCG Report', href: 'https://web-assets.bcg.com/1e/a2/5b5f2b7e42dfad2cb3113a291222/bcg-relevance-of-on-chain-asset-tokenization-in-crypto-winter-oct-2022.pdf' },
          { title: 'Tokenized Treasuries', value: '$1.42B+', icon: <Activity className="w-4 h-4 text-red-600" />, source: 'RWA.xyz', href: 'https://app.rwa.xyz/treasuries' },
          { title: 'Active Protocols', value: '3,400+', icon: <BarChart3 className="w-4 h-4 text-red-600" />, source: 'DeFiLlama', href: 'https://defillama.com/protocols' },
        ].map((stat, i) => (
          <div key={i} className="bg-white border border-slate-200 shadow-sm p-5 rounded-md relative flex flex-col justify-between">
            <div>
              <div className="flex items-center space-x-2 text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-3">
                {stat.icon}
                <span>{stat.title}</span>
              </div>
              <div className="text-2xl font-black tracking-tight text-blue-900 mb-2">{stat.value}</div>
            </div>
            <a href={stat.href} target="_blank" rel="noopener noreferrer" className="text-[9px] text-blue-600 hover:underline uppercase tracking-wider font-bold block mt-2">
              Source: {stat.source}
            </a>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="bg-white border border-slate-200 shadow-sm p-5 rounded-md">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-blue-900 tracking-tight">Total Addressable Market (TAM) Forecast</h3>
            <p className="text-xs text-slate-600 mt-1">Comparing DeFi vs TradFi tokenized market sizing over 10 years (in Billions USD).</p>
            <p className="text-[10px] text-slate-400 mt-0.5">Source: <a href="https://icg.citi.com/icghome/what-we-think/citigps/insights/money-tokens-and-games" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 underline">Citi GPS: Money, Tokens, and Games Report</a> & <a href="https://web-assets.bcg.com/1e/a2/5b5f2b7e42dfad2cb3113a291222/bcg-relevance-of-on-chain-asset-tokenization-in-crypto-winter-oct-2022.pdf" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 underline">BCG Tokenization Report</a>.</p>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tamForecastData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="year" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} tickFormatter={(val) => `$${val}B`} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }} 
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '4px', border: '1px solid #cbd5e1', color: '#0f172a' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#475569' }}/>
                <Bar dataKey="defiTAM" name="DeFi Markets" stackId="a" fill="#002d72" radius={[0, 0, 0, 0]} />
                <Bar dataKey="tradfiTAM" name="TradFi Markets" stackId="a" fill="#e31937" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-slate-200 shadow-sm p-5 rounded-md flex flex-col">
          <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-blue-900 tracking-tight">Asset Manager Flows</h3>
              <p className="text-xs text-slate-600 mt-1">Aggregating historical flow data baselined from industry standards.</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Source: <a href="https://app.rwa.xyz/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 underline">RWA.xyz</a> & <a href="https://app.artemis.xyz/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 underline">Artemis Terminal</a>.</p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex bg-slate-100 p-1 rounded-md border border-slate-200">
                {['3M', '6M', 'YTD', '1Y'].map((period) => (
                  <button
                    key={period}
                    onClick={() => setTimePeriod(period)}
                    className={`px-3 py-1 text-[11px] font-bold rounded-sm transition-colors ${timePeriod === period ? 'bg-white text-slate-900 shadow-sm border border-slate-200' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    {period}
                  </button>
                ))}
              </div>
              <select
                value={assetClass}
                onChange={(e) => setAssetClass(e.target.value)}
                className="bg-white border border-slate-200 text-slate-700 text-[11px] font-bold rounded-md px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="All">All Assets</option>
                <option value="RWA">RWA Only</option>
                <option value="Stablecoins">Stablecoins Only</option>
                <option value="Indices">Indices Only</option>
              </select>
            </div>
          </div>
          <div className="h-72 w-full mt-auto">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={filteredData} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRwa" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00A9E0" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00A9E0" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorIndex" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#e31937" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#e31937" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} tickFormatter={(val) => `$${val}B`} />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderRadius: '4px', border: '1px solid #cbd5e1', color: '#0f172a' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#475569' }}/>
                {(assetClass === 'All' || assetClass === 'Stablecoins') && (
                  <Area type="monotone" dataKey="Stablecoins" name="Stablecoins" stroke="#94a3b8" fill="transparent" strokeDasharray="5 5" />
                )}
                {(assetClass === 'All' || assetClass === 'RWA') && (
                  <Area type="monotone" dataKey="RWA" name="RWAs" stroke="#00A9E0" fillOpacity={1} fill="url(#colorRwa)" />
                )}
                {(assetClass === 'All' || assetClass === 'Indices') && (
                  <Area type="monotone" dataKey="Indices" name="On-chain Indices" stroke="#e31937" fillOpacity={1} fill="url(#colorIndex)" strokeWidth={2} />
                )}
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 shadow-sm p-5 rounded-md mt-6">
        <div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-lg font-bold text-blue-900 tracking-tight flex items-center">
              <Server className="w-5 h-5 mr-2 text-blue-600" /> Real-Time TVL Tracking
            </h3>
            <p className="text-xs text-slate-600 mt-1">Live data sourced directly from DeFiLlama public API.</p>
          </div>
          <span className="bg-blue-50 text-blue-700 text-[10px] font-bold tracking-widest px-2.5 py-1 uppercase rounded-sm flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2 animate-pulse"></span> LIVE
          </span>
        </div>
        
        <RealTimeTVLTable />
      </div>

    </div>
  );
}

function RealTimeTVLTable() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch('/api/market-data');
        if (response.ok) {
          const result = await response.json();
          setData(result);
        }
      } catch (e) {
        console.error("Failed to fetch market data", e);
      } finally {
        setLoading(false);
      }
    }
    
    fetchData();
    const interval = setInterval(fetchData, 120000); // 2 minutes
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return <div className="text-xs text-slate-500 py-6 text-center animate-pulse">Connecting to DeFiLlama Oracles...</div>;
  }

  if (data.length === 0) {
    return <div className="text-xs text-slate-500 py-6 text-center">No real-time data available. Check API limits.</div>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-slate-200 text-xs uppercase tracking-widest text-slate-500 font-bold bg-slate-50">
            <th className="px-4 py-3 rounded-tl-sm">Protocol</th>
            <th className="px-4 py-3">Category</th>
            <th className="px-4 py-3">Chain</th>
            <th className="px-4 py-3 text-right rounded-tr-sm">TVL (USD)</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
              <td className="px-4 py-3 font-bold text-blue-900 flex items-center">
                {row.name}
                {row.symbol && <span className="ml-2 text-[10px] font-mono text-slate-500 tracking-wider bg-slate-100 px-1.5 py-0.5 rounded-sm">{row.symbol}</span>}
              </td>
              <td className="px-4 py-3 text-slate-600 text-xs">{row.category}</td>
              <td className="px-4 py-3 text-slate-600 text-xs capitalize">{row.chain}</td>
              <td className="px-4 py-3 text-right font-mono font-bold text-slate-900 text-xs">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(row.tvl)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
