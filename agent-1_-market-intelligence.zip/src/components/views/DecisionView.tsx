import React from 'react';
import { Lightbulb, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';

export default function DecisionView() {
  return (
    <div className="space-y-6">
      <div>
        <span className="text-[10px] tracking-[0.1em] text-red-600 font-bold uppercase mb-1 block">Strategic Horizon</span>
        <h2 className="text-3xl font-black font-sans tracking-tight text-blue-900 mb-1">Decision Support & Strategy</h2>
        <p className="text-sm text-slate-600">Synthesized recommendations for S&P DJI structural positioning.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6 border-l-[4px] border-l-blue-600">
          <div className="flex items-center space-x-2 mb-4 text-blue-700">
            <CheckCircle2 className="w-5 h-5" />
            <h3 className="font-bold uppercase text-xs tracking-widest text-blue-900">Recommended Entries (6-18 Mos)</h3>
          </div>
          <ul className="space-y-4">
            <li className="flex items-start bg-slate-50 p-4 rounded-md border border-slate-200">
              <span className="bg-blue-100 text-blue-700 font-bold text-[10px] tracking-widest px-2.5 py-1 uppercase rounded-sm flex-shrink-0 mr-3 mt-0.5">HIGH</span>
              <div>
                <span className="font-bold block text-sm tracking-tight text-blue-900">RWA Yield Indices</span>
                <span className="text-xs text-slate-600 mt-1 block leading-relaxed">Index for tokenized treasury products. Directly aligns with TradFi client needs seeking on-chain yields with verifiable backed assets.</span>
              </div>
            </li>
            <li className="flex items-start bg-slate-50 p-4 rounded-md border border-slate-200">
              <span className="bg-blue-50 text-blue-600 font-bold text-[10px] tracking-widest px-2.5 py-1 uppercase rounded-sm flex-shrink-0 mr-3 mt-0.5">MED</span>
              <div>
                <span className="font-bold block text-sm tracking-tight text-blue-900">LST/LRT Benchmarks</span>
                <span className="text-xs text-slate-600 mt-1 block leading-relaxed">Standardizing Ethereum staking yields for institutional reporting.</span>
              </div>
            </li>
          </ul>
        </div>

        <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6 border-l-[4px] border-l-red-500">
          <div className="flex items-center space-x-2 mb-4 text-red-600">
            <XCircle className="w-5 h-5" />
            <h3 className="font-bold uppercase text-xs tracking-widest text-blue-900">Segments to Avoid</h3>
          </div>
          <ul className="space-y-4">
            <li className="flex items-start bg-slate-50 p-4 rounded-md border border-slate-200">
              <span className="bg-red-50 text-red-600 font-bold text-[10px] tracking-widest px-2.5 py-1 uppercase rounded-sm flex-shrink-0 mr-3 mt-0.5">AVOID</span>
              <div>
                <span className="font-bold block text-sm tracking-tight text-blue-900">Meme-Coin Oracles</span>
                <span className="text-xs text-slate-600 mt-1 block leading-relaxed">High reputational risk, zero alignment with core S&P methodology.</span>
              </div>
            </li>
            <li className="flex items-start bg-slate-50 p-4 rounded-md border border-slate-200">
              <span className="bg-red-50 text-red-600 font-bold text-[10px] tracking-widest px-2.5 py-1 uppercase rounded-sm flex-shrink-0 mr-3 mt-0.5">AVOID</span>
              <div>
                <span className="font-bold block text-sm tracking-tight text-blue-900">Undercollateralized Lending protocols</span>
                <span className="text-xs text-slate-600 mt-1 block leading-relaxed">High structural contagion risk; lack of regulatory clarity for index inclusion.</span>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <div className="bg-white border border-slate-200 shadow-sm rounded-md p-6 relative">
        <h3 className="font-bold uppercase text-xs tracking-widest flex items-center mb-6 text-blue-900">
          <Lightbulb className="w-4 h-4 text-blue-600 mr-2" /> Partner Recommendation Matrix
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-b border-slate-200 pb-2">Credible Partners</h4>
            <ul className="space-y-3 text-xs pt-2 font-medium">
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-blue-600" /> Securitize (Issuance)</li>
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-blue-600" /> Centrifuge (RWA rails)</li>
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-blue-600" /> Ondo Finance (Products)</li>
            </ul>
          </div>
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-b border-slate-200 pb-2">Monitor Closely</h4>
            <ul className="space-y-3 text-xs pt-2 font-medium">
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-slate-400" /> Hyperliquid (Perps venue)</li>
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-slate-400" /> Artemis Terminal (Data)</li>
            </ul>
          </div>
          <div className="space-y-2">
             <h4 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-b border-slate-200 pb-2">Client Focus</h4>
            <ul className="space-y-3 text-xs pt-2 font-medium">
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-slate-400" /> Asset Managers / ETF Issuers</li>
              <li className="flex items-center text-slate-700"><ArrowRight className="w-3 h-3 mr-2 text-slate-400" /> Custodians & Fund Admins</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

