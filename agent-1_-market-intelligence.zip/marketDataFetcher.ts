import axios from 'axios';

export async function fetchMarketData() {
  try {
    // We can fetch data from DeFiLlama for specific protocols
    // e.g. Hyperliquid, Ondo, Centrifuge
    
    // As a demonstration of real integration, we'll fetch real TVL stats
    const response = await axios.get('https://api.llama.fi/protocols');
    const protocols = response.data;
    
    const targets = ['Ondo', 'Centrifuge', 'Hyperliquid', 'Securitize', 'Maple Finance', 'MakerDAO', 'Pendle', 'Aave V3'];
    const filtered = protocols.filter((p: any) => targets.includes(p.name));
    
    return filtered.map((p: any) => ({
      name: p.name,
      symbol: p.symbol,
      tvl: p.tvl,
      category: p.category,
      chain: p.chain
    }));
  } catch (error) {
    console.error("Error fetching from DeFiLlama", error);
    return [];
  }
}
