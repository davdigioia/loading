import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { initScheduler } from './scheduler';

dotenv.config();

const app = express();
const PORT = 3000;

import { fetchLiveNews } from './newsFetcher';
import { fetchMarketData } from './marketDataFetcher';

app.use(express.json());

app.get('/api/market-data', async (req, res) => {
  try {
    const data = await fetchMarketData();
    res.json(data);
  } catch (error: any) {
    console.error('Error fetching market data:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/live-data', async (req, res) => {
  try {
    const data = await fetchLiveNews();
    res.json(data);
  } catch (error: any) {
    console.error('Error fetching live data:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/generate-dossier', async (req, res) => {
  try {
    const { competitor, context } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required.");
    }
    
    const ai = new GoogleGenAI({ apiKey });
    
    const promptContext = context ? `Context: ${context}.` : '';
    const prompt = `Generate a highly professional, detailed, up-to-date threat analysis dossier on the competitor: ${competitor}. ${promptContext} Focus on recent crypto/ DeFi / TradFi moves, partnerships, latest news, and relevance to S&P DJI. Use bullet points and a very analytical tone. Interpret and synthesize the market data, identify gaps, contradictions, and challenger points in their strategy. Draw upon your prior knowledge of the TradFi/DeFi bridge. Give actionable conclusions. Keep it concise.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    
    res.json({ dossier: response.text });
  } catch (error: any) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/agent-query', async (req, res) => {
  try {
    const { query, history } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing.");
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const formattedHistory = history.map((msg: any) => ({
      role: msg.role === 'agent' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: "System prompt: You are an analytical AI agent embedded within an S&P DJI DeFi research dashboard. You monitor real-time indices, RWA tokenization, and competitors. Your core functions: interpret and synthesize data, summarize and apply prior knowledge, look for gaps/contradictions/challenger points, and reference known positions. Respond in a highly professional, clinical, data-driven tone. Keep answers under 150 words." }] },
        { role: 'model', parts: [{ text: "Acknowledged." }] },
        ...formattedHistory,
        { role: 'user', parts: [{ text: query }]}
      ],
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    res.json({ reply: response.text });
  } catch (e: any) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    initScheduler();
  });
}

startServer();
