import Parser from 'rss-parser';

const parser = new Parser();

export async function fetchLiveNews() {
  const sources = [
    { name: 'CoinDesk', url: 'https://www.coindesk.com/arc/outboundfeeds/rss/' },
    { name: 'CoinTelegraph', url: 'https://cointelegraph.com/rss' },
    { name: 'CNBC', url: 'https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=10000664' } // CNBC Finance
  ];

  let allNews: any[] = [];

  for (const source of sources) {
    try {
      const feed = await parser.parseURL(source.url);
      const latest = feed.items.slice(0, 5).map(item => ({
        source: source.name,
        title: item.title,
        link: item.link,
        date: item.pubDate,
      }));
      allNews = [...allNews, ...latest];
    } catch (error) {
      console.error(`Error fetching from ${source.name}:`, error);
    }
  }

  // Sort by date descending
  return allNews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}
