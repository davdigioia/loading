import React, { useState, useRef, useEffect } from "react";
import { Terminal, Send, Loader2, RefreshCw, Cpu, User, ArrowRight, ShieldCheck, Sparkles } from "lucide-react";
import { ChatMessage } from "../types";

interface AgentTerminalProps {
  chatHistory: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  isResponding: boolean;
}

export default function AgentTerminal({ chatHistory, onSendMessage, isResponding }: AgentTerminalProps) {
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const starterQuestions = [
    "Write a secure dynamic loader script utilizing importlib and AST parsing",
    "Explain how Active Inference limits entropy inside evolving multiagent states",
    "How can a self-updating agent system handle dynamic package version conflicts?"
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isResponding) return;
    onSendMessage(inputText.trim());
    setInputText("");
  };

  const handleStarterClick = (question: string) => {
    if (isResponding) return;
    onSendMessage(question);
  };

  // Auto-scroll to the bottom of the terminal on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isResponding]);

  return (
    <div id="agent-terminal" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Instructions & System Stats Sidebar */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-5 shadow-xl space-y-4 lg:col-span-1 backdrop-blur-md">
        <div className="flex items-center space-x-2 border-b border-white/5 pb-3">
          <Terminal className="h-4.5 w-4.5 text-indigo-400" />
          <h3 className="font-display text-xs font-semibold text-white uppercase tracking-wider">
            System Directive
          </h3>
        </div>

        <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
          This is your specialized evolutionary communication node. It provides a direct telemetry link to the core research specialist.
        </p>

        <div className="space-y-3 pt-2">
          <span className="block text-[10px] font-mono uppercase tracking-widest text-slate-550">Suggested Inquiries</span>
          <div className="space-y-2">
            {starterQuestions.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleStarterClick(q)}
                className="w-full text-left p-2.5 bg-[#020408]/60 border border-white/5 hover:bg-white/10 hover:border-white/20 rounded-xl text-[11px] text-slate-300 leading-normal transition-all flex items-start space-x-2 cursor-pointer"
              >
                <ArrowRight className="h-3.5 w-3.5 text-indigo-400 shrink-0 mt-0.5" />
                <span className="font-mono">{q}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2 border-t border-white/5 space-y-2.5 text-slate-400">
          <div className="flex items-center justify-between text-[11px] font-mono">
            <span>AST Shield Level:</span>
            <span className="text-emerald-400 font-bold flex items-center space-x-1">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>STRICT</span>
            </span>
          </div>
          <div className="flex items-center justify-between text-[11px] font-mono">
            <span>Security Signature:</span>
            <span className="text-slate-300">SH_v2_26_OK</span>
          </div>
        </div>
      </div>

      {/* Main Terminal Chat Area */}
      <div className="bg-white/5 border border-white/10 rounded-2xl flex flex-col h-[520px] shadow-2xl lg:col-span-3 backdrop-blur-md">
        
        {/* Terminal Header */}
        <div className="px-5 py-3.5 border-b border-white/5 bg-white/3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Cpu className="h-4 w-4 text-indigo-400" />
            <h4 className="font-display text-xs font-semibold text-slate-200 uppercase tracking-widest">
              Researcher Agent Matrix Command Prompt
            </h4>
          </div>
          <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded px-2 py-0.5 font-mono uppercase tracking-wider">
            SECURE_LINK
          </span>
        </div>

        {/* Console Message Streams */}
        <div className="flex-1 overflow-y-auto p-5 bg-[#020408]/40 space-y-4 font-sans text-xs scrollbar select-text">
          {chatHistory.map((msg) => {
            const isAgent = msg.sender === "agent";
            return (
              <div
                key={msg.id}
                className={`flex items-start space-x-3.5 p-3.5 rounded-2xl border max-w-[85%] ${
                  isAgent
                    ? "bg-[#020408]/60 border-white/5 mr-auto text-slate-200"
                    : "bg-indigo-500/10 border-indigo-500/20 ml-auto flex-row-reverse space-x-reverse text-slate-100"
                }`}
              >
                {/* Profile Icon */}
                <div className={`p-1.5 rounded-lg ${
                  isAgent ? "bg-white/5 border border-white/10 text-indigo-405 text-indigo-400" : "bg-indigo-600 text-white"
                }`}>
                  {isAgent ? <Cpu className="h-3.5 w-3.5" /> : <User className="h-3.5 w-3.5" />}
                </div>

                {/* Message Text */}
                <div className="space-y-1.5 min-w-0 flex-1 leading-relaxed">
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span className="font-mono font-bold uppercase tracking-wider">
                      {isAgent ? "Autonomous Specialist Node" : "Local Operator Node"}
                    </span>
                    <span className="font-mono ml-2">
                      {msg.timestamp}
                    </span>
                  </div>
                  <div className="leading-relaxed select-text font-serif-none font-sans text-slate-300 pr-1">
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })}

          {isResponding && (
            <div className="flex items-start space-x-3.5 p-3.5 rounded-2xl border mr-auto bg-[#020408]/60 border-white/5">
              <div className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-indigo-400 animate-pulse">
                <Cpu className="h-3.5 w-3.5" />
              </div>
              <div className="space-y-2 flex-1">
                <div className="flex items-center space-x-2 text-[10px] text-slate-500">
                  <span className="font-mono font-bold uppercase tracking-widest">Specialist Computing...</span>
                  <Loader2 className="h-3 w-3 animate-spin text-indigo-400" />
                </div>
                <div className="flex items-center space-x-1.5 text-xs text-slate-400">
                  <Sparkles className="h-3.5 w-3.5 text-indigo-400 animate-pulse" />
                  <span className="font-mono text-[11px]">Synthesizing structural python scripts. Formulating adaptation schemas with Gemini models...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-4 bg-[#020408]/80 border-t border-white/5 flex items-center space-x-3">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Query evolution models or request sandboxing blueprints..."
            className="flex-1 bg-[#020408]/60 border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
            disabled={isResponding}
          />
          <button
            type="submit"
            disabled={isResponding || !inputText.trim()}
            className={`p-2.5 rounded-lg border transition-all flex items-center justify-center shrink-0 cursor-pointer ${
              inputText.trim() && !isResponding
                ? "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.3)] font-bold"
                : "bg-white/5 border-white/10 text-slate-600 cursor-not-allowed"
            }`}
          >
            {isResponding ? (
              <Loader2 className="h-4 w-4 animate-spin text-indigo-400" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
