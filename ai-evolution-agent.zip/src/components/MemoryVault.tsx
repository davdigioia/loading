import React, { useState } from "react";
import { BookOpen, Search, ExternalLink, Calendar, Code, CheckSquare, Square, RefreshCw, AlertTriangle } from "lucide-react";
import { LearnedItem } from "../types";

interface MemoryVaultProps {
  vault: LearnedItem[];
  selectedIds: string[];
  onToggleSelectItem: (id: string) => void;
  onSelectTab: (tab: "vault" | "scanner" | "blueprint" | "terminal") => void;
}

export default function MemoryVault({ vault, selectedIds, onToggleSelectItem, onSelectTab }: MemoryVaultProps) {
  const [filterSource, setFilterSource] = useState<"all" | "arXiv" | "Medium">("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [syntaxStatus, setSyntaxStatus] = useState<Record<string, "idle" | "verifying" | "valid">>({});

  const filteredItems = vault.filter((item) => {
    const matchesSource = filterSource === "all" || item.source === filterSource;
    const matchesSearch = 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      item.pythonLibrary.toLowerCase().includes(searchTerm.toLowerCase()) || 
      item.keyBreakthrough.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSource && matchesSearch;
  });

  const testCodeSyntax = (id: string, code: string) => {
    setSyntaxStatus(prev => ({ ...prev, [id]: "verifying" }));
    setTimeout(() => {
      setSyntaxStatus(prev => ({ ...prev, [id]: "valid" }));
    }, 1200);
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    alert("Python integration blueprint script copied to clipboard!");
  };

  return (
    <div id="memory-vault" className="space-y-6">
      
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between shadow-lg backdrop-blur-md">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Learned Assets</span>
          <div className="flex items-baseline space-x-2 mt-2">
            <span className="text-3xl font-display font-bold text-indigo-400">{vault.length}</span>
            <span className="text-xs text-slate-400 font-mono">Unique Nodes</span>
          </div>
        </div>
        
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between shadow-lg backdrop-blur-md">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Channels Harvested</span>
          <div className="flex items-baseline space-x-2 mt-2">
            <span className="text-3xl font-display font-bold text-white">
              {vault.filter(n => n.source === "arXiv").length}
            </span>
            <span className="text-xs text-indigo-400 font-mono">Scientific Papers</span>
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between shadow-lg backdrop-blur-md">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Modification Queue</span>
          <div className="flex items-baseline space-x-2 mt-2">
            <span className="text-3xl font-display font-bold text-indigo-400">{selectedIds.length}</span>
            <span className="text-xs text-slate-400 font-mono">Active Targets</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-md backdrop-blur-md">
        <div className="flex space-x-1 bg-[#020408]/60 p-1 rounded-lg border border-white/5 w-full md:w-auto">
          {(["all", "arXiv", "Medium"] as const).map((source) => (
            <button
              key={source}
              type="button"
              onClick={() => setFilterSource(source)}
              className={`flex-1 md:flex-none px-4 py-1.5 rounded-md text-[11px] font-mono transition-colors uppercase tracking-wider cursor-pointer ${
                filterSource === source
                  ? "bg-indigo-500/20 text-white border border-indigo-500/30 font-semibold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {source}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-500" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search learned modules..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#020408]/60 border border-white/10 rounded-lg text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-all"
          />
        </div>
      </div>

      {/* Main List Grid */}
      <div className="space-y-4">
        {filteredItems.length === 0 ? (
          <div className="bg-white/5 border border-white/10 rounded-2xl py-12 px-4 text-center backdrop-blur-md">
            <AlertTriangle className="h-8 w-8 text-indigo-400 mx-auto mb-3" />
            <p className="text-sm font-semibold text-slate-200 font-display">No learned modules located</p>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Change your filters or head to the **Live Search Engine** to run an active Grounded query against arXiv or Medium AI tags!
            </p>
            <button
              type="button"
              onClick={() => onSelectTab("scanner")}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white font-mono text-xs rounded-lg hover:bg-indigo-500 font-bold transition-all shadow-[0_0_15px_rgba(99,102,241,0.3)] cursor-pointer"
            >
              Configure Live Search
            </button>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isSelected = selectedIds.includes(item.id);
            const isExpanded = expandedItemId === item.id;
            const itemSyntax = syntaxStatus[item.id] || "idle";

            return (
              <div
                key={item.id}
                className={`group border rounded-xl overflow-hidden transition-all duration-200 ${
                  isSelected 
                    ? "bg-indigo-950/20 border-indigo-500/50 shadow-[0_0_15px_rgba(99,102,241,0.15)]" 
                    : "bg-[#020408]/40 border-white/10 hover:border-white/20"
                }`}
              >
                {/* Header Container */}
                <div 
                  className={`p-5 flex items-start justify-between cursor-pointer ${
                    isExpanded ? "border-b border-white/5 bg-white/2" : ""
                  }`}
                  onClick={() => setExpandedItemId(isExpanded ? null : item.id)}
                >
                  <div className="space-y-2 flex-1 pr-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-semibold uppercase ${
                        item.source === "arXiv" 
                          ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {item.source}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {item.id}
                      </span>
                      <div className="flex items-center text-[10px] text-slate-500">
                        <Calendar className="h-3 w-3 mr-1 text-slate-600" />
                        {item.date}
                      </div>
                    </div>

                    <h3 className="font-display font-semibold text-sm md:text-base text-white tracking-tight leading-snug group-hover:text-indigo-400 transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-[11px] font-mono text-slate-400">
                      Research authors: <span className="text-slate-300 font-sans">{item.authors}</span>
                    </p>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0 py-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={() => onToggleSelectItem(item.id)}
                      className="p-1 px-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-md text-xs text-slate-400 hover:text-white flex items-center space-x-1.5 transition-all cursor-pointer"
                      title={isSelected ? "Deselect from Evolution Pipeline" : "Select for Self-Evolution Protocol"}
                    >
                      {isSelected ? (
                        <>
                          <CheckSquare className="h-3.5 w-3.5 text-indigo-400" />
                          <span className="text-[10px] font-mono text-indigo-400 font-bold">QUEUED</span>
                        </>
                      ) : (
                        <>
                          <Square className="h-3.5 w-3.5 text-slate-600" />
                          <span className="text-[10px] font-mono text-slate-500">SELECT</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Always-visible Mini Snapshot */}
                {!isExpanded && (
                  <div className="px-5 py-3.5 bg-[#020408]/60 text-xs flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-t border-white/5 border-dashed">
                    <div className="flex items-center space-x-2">
                      <Code className="h-3.5 w-3.5 text-indigo-400 shrink-0" />
                      <span className="text-slate-400">Target library: <strong className="text-white font-mono">{item.pythonLibrary}</strong></span>
                    </div>
                    <div className="flex items-center space-x-1.5 text-slate-400">
                      <span>{item.keyBreakthrough.substring(0, 75)}...</span>
                      <button 
                        type="button"
                        onClick={() => setExpandedItemId(item.id)}
                        className="text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                )}

                {/* Expanded Details Pane */}
                {isExpanded && (
                  <div className="p-5 bg-[#020408]/80 border-t border-white/5 space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div className="space-y-3">
                        <h4 className="text-xs font-mono uppercase tracking-wider text-indigo-300">Key Scientific Breakthrough</h4>
                        <p className="text-xs text-slate-300 leading-relaxed bg-[#020408]/40 p-3 rounded-lg border border-white/5">
                          {item.keyBreakthrough}
                        </p>

                        <h4 className="text-xs font-mono uppercase tracking-wider text-indigo-300">Self-Evolution Adaptation Blueprint</h4>
                        <p className="text-xs text-slate-300 leading-relaxed bg-[#020408]/40 p-3 rounded-lg border border-white/5">
                          {item.adaptationBlueprint}
                        </p>
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-xs font-mono uppercase tracking-wider text-indigo-300">Impact on Cognitive Evolution</h4>
                        <p className="text-xs text-slate-300 leading-relaxed bg-[#020408]/40 p-3 rounded-lg border border-white/5">
                          {item.evolutionMechanics}
                        </p>

                        <div className="flex items-center justify-between text-xs pt-1">
                          <span className="text-slate-500 font-mono">Reference url:</span>
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-indigo-400 hover:text-indigo-300 flex items-center hover:underline font-mono"
                          >
                            <span>Open publication source</span>
                            <ExternalLink className="h-3 w-3 ml-1" />
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Code block area */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Code className="h-3.5 w-3.5 text-indigo-400" />
                          <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">Dynamic Python Integration Loop</h4>
                        </div>
                        <div className="flex items-center space-x-2" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => testCodeSyntax(item.id, item.integrationCode)}
                            className="px-2.5 py-1 bg-white/5 border border-white/10 hover:border-white/20 text-[10px] font-mono rounded flex items-center space-x-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
                          >
                            {itemSyntax === "verifying" ? (
                              <>
                                <RefreshCw className="h-3 w-3 animate-spin text-indigo-400" />
                                <span className="text-indigo-300">AST_PARSING...</span>
                              </>
                            ) : itemSyntax === "valid" ? (
                              <>
                                <span className="text-emerald-400 font-bold">● SYNTAX_VALID</span>
                              </>
                            ) : (
                              <>
                                <RefreshCw className="h-3 w-3 text-slate-400" />
                                <span>Parse AST Check</span>
                              </>
                            )}
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => handleCopyCode(item.integrationCode)}
                            className="px-2.5 py-1 bg-white/5 border border-white/10 hover:border-white/20 text-[10px] font-mono rounded text-slate-300 hover:text-white transition-colors cursor-pointer"
                          >
                            Copy Script
                          </button>
                        </div>
                      </div>

                      <div className="relative">
                        <pre className="p-4 bg-black/80 border border-white/5 rounded-lg text-[11px] font-mono text-slate-200 overflow-x-auto max-h-60 leading-relaxed scrollbar">
                          <code>{item.integrationCode}</code>
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Synthesis Call-to-action bar */}
      {selectedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-2xl bg-indigo-900 border border-indigo-400/30 rounded-xl p-4 shadow-[0_0_30px_rgba(99,102,241,0.4)] flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-100 z-30 backdrop-blur-md">
          <div className="flex items-center space-x-3 text-left">
            <div className="p-2 bg-indigo-600 text-white rounded-lg">
              <BookOpen className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs font-semibold font-display">Adaptation Targets Connected</p>
              <p className="text-[10px] text-indigo-200/95 font-mono">{selectedIds.length} scientific breakthrough(s) loaded into planning chamber.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onSelectTab("blueprint")}
            className="px-4 py-2 bg-[#020408] hover:bg-black text-indigo-300 text-xs font-mono rounded-lg border border-indigo-500/20 shadow-md font-bold transition-transform cursor-pointer shrink-0"
          >
            SYNTHESIZE ADAPTATION ROADMAP →
          </button>
        </div>
      )}
    </div>
  );
}
