import React, { useState } from "react";
import { Search, Compass, Loader2, ArrowRight, BookOpen, AlertTriangle, RefreshCw, Layers } from "lucide-react";
import { LearnedItem, ScanLog } from "../types";

interface ScanConsoleProps {
  logs: ScanLog[];
  onStartScan: (source: "arxiv" | "medium" | "both", query: string) => Promise<void>;
  isScanning: boolean;
  onSelectTab: (tab: "vault" | "scanner" | "blueprint" | "terminal") => void;
}

export default function ScanConsole({ logs, onStartScan, isScanning, onSelectTab }: ScanConsoleProps) {
  const [source, setSource] = useState<"arxiv" | "medium" | "both">("both");
  const [query, setQuery] = useState("");

  const suggestedQueries = [
    "dynamic AST Python libraries for agents",
    "self modifying code multi agent recursive loops",
    "active inference agent framework adaptation",
    "dynamic python imports sandbox packages"
  ];

  const handleScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStartScan(source, query);
  };

  return (
    <div id="scan-console" className="space-y-6">
      {/* Target Setup Card */}
      <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-md">
        <div className="px-5 py-4 border-b border-white/5 bg-white/3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse-ring" />
            <h2 className="font-display text-sm font-semibold text-white tracking-tight">Crawl & Scan Parameters</h2>
          </div>
          <span className="text-[10px] font-mono px-2.5 py-0.5 bg-indigo-500/10 text-indigo-300 rounded border border-indigo-500/20 uppercase tracking-wider">CRAWL_BEAM_v1.2</span>
        </div>

        <form onSubmit={handleScanSubmit} className="p-6 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">Target Academic Channels</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSource("arxiv")}
                  className={`py-2 px-3 rounded-lg border text-xs font-mono transition-all text-center cursor-pointer ${
                    source === "arxiv"
                      ? "bg-indigo-500/20 border-indigo-500 text-white font-semibold"
                      : "bg-[#020408]/60 border-white/5 text-slate-400 hover:border-white/10 hover:text-slate-200"
                  }`}
                >
                  arxiv.org
                </button>
                <button
                  type="button"
                  onClick={() => setSource("medium")}
                  className={`py-2 px-3 rounded-lg border text-xs font-mono transition-all text-center cursor-pointer ${
                    source === "medium"
                      ? "bg-indigo-500/20 border-indigo-500 text-white font-semibold"
                      : "bg-[#020408]/60 border-white/5 text-slate-400 hover:border-white/10 hover:text-slate-200"
                  }`}
                >
                  Medium AI
                </button>
                <button
                  type="button"
                  onClick={() => setSource("both")}
                  className={`py-2 px-3 rounded-lg border text-xs font-mono transition-all text-center cursor-pointer ${
                    source === "both"
                      ? "bg-indigo-500/20 border-indigo-500 text-white font-semibold"
                      : "bg-[#020408]/60 border-white/5 text-slate-400 hover:border-white/10 hover:text-slate-200"
                  }`}
                >
                  Dual Scan
                </button>
              </div>
              <p className="mt-2 text-[10px] text-slate-500 font-mono">
                Determines where our search grounding agent targets crawling queries.
              </p>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">Concept Focus / Query Filters</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-500" />
                </div>
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. self-modifying, AST loaders, pyactiveinference..."
                  className="w-full pl-9 pr-3 py-2 bg-[#020408]/60 border border-white/10 rounded-lg text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                  disabled={isScanning}
                />
              </div>
              <p className="mt-2 text-[10px] text-slate-500 font-mono">
                Instructs search grounding regarding target specialized logic.
              </p>
            </div>
          </div>

          <div>
            <span className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">Self-Evolution Core Keywords</span>
            <div className="flex flex-wrap gap-2">
              {suggestedQueries.map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setQuery(item)}
                  className="px-2.5 py-1 rounded bg-[#020408]/60 border border-white/5 text-[10px] font-mono text-slate-400 hover:text-indigo-400 hover:border-indigo-500/50 transition-colors cursor-pointer"
                >
                  #{item}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={isScanning}
              className={`px-5 py-2.5 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                isScanning
                  ? "bg-indigo-950/40 border border-indigo-800/40 text-indigo-400 cursor-not-allowed"
                  : "bg-indigo-600 text-white hover:bg-indigo-500 font-bold shadow-[0_0_15px_rgba(99,102,241,0.3)] hover:shadow-[0_0_25px_rgba(99,102,241,0.5)]"
              }`}
            >
              {isScanning ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  <span>Harvesting Knowledge Web...</span>
                </>
              ) : (
                <>
                  <Compass className="h-3.5 w-3.5" />
                  <span>Activate Scientific Search Beam</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Cybernetic Scan Monitor / Logs */}
      <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-md">
        <div className="px-5 py-3.5 border-b border-white/5 bg-white/3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Layers className="h-4 w-4 text-indigo-400" />
            <h3 className="font-display text-sm font-semibold text-white">Active Scan Log Console</h3>
          </div>
          <div className="flex items-center space-x-1.5 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-[9px] text-emerald-400 uppercase tracking-widest font-semibold">Telemetry Connected</span>
          </div>
        </div>

        <div className="p-4 bg-white/2 border-b border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Targeting: <span className="text-slate-300">arxiv.org</span> & <span className="text-slate-300">medium.com/feed/tag/ai</span></span>
          <span>COOR_ID: {Math.floor(Math.random() * 900000 + 100000)}</span>
        </div>

        <div className="p-4 bg-[#020408]/80 font-mono text-xs text-slate-300 max-h-72 overflow-y-auto space-y-2 select-all h-60 scrollbar">
          {logs.map((log, index) => {
            const levelColor = 
              log.level === "SUCCESS" 
                ? "text-emerald-400" 
                : log.level === "WARN" 
                ? "text-amber-400" 
                : "text-indigo-400";
            return (
              <div key={index} className="flex items-start space-x-2 py-0.5 border-b border-white/5">
                <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
                <span className={`font-semibold shrink-0 ${levelColor}`}>[{log.level}]</span>
                <span className="text-slate-300 leading-snug">{log.message}</span>
              </div>
            );
          })}
          {isScanning && (
            <div className="flex items-center space-x-2 py-2 text-indigo-400 animate-pulse">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              <span>[Gemini Search Grounding Processor] Actively running web citations evaluation. Awaiting structured code blueprint vector...</span>
            </div>
          )}
        </div>

        {/* Action Suggestion Footer */}
        <div className="p-4 bg-[#020408]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs border-t border-white/5">
          <div className="flex items-center space-x-2 text-slate-400">
            <BookOpen className="h-4 w-4 text-indigo-400 shrink-0" />
            <span>Scanning injects verified research papers with actual Python libraries directly into the vault.</span>
          </div>
          <button 
            type="button"
            onClick={() => onSelectTab("vault")}
            className="text-indigo-400 hover:text-indigo-300 font-mono text-xs flex items-center space-x-1 uppercase tracking-wider shrink-0 cursor-pointer"
          >
            <span>Open Memory Vault</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
