import React, { useState, useEffect } from "react";
import { Cpu, Database, Compass, Layers, Terminal, Sparkles, BookOpen, ChevronRight, CheckCircle2, Sliders, Play, Server, RefreshCw, BarChart2 } from "lucide-react";
import { ActiveTab, LearnedItem, ScanLog, ChatMessage } from "./types";
import MemoryVault from "./components/MemoryVault";
import ScanConsole from "./components/ScanConsole";
import BlueprintPlanner from "./components/BlueprintPlanner";
import AgentTerminal from "./components/AgentTerminal";

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("vault");
  const [vault, setVault] = useState<LearnedItem[]>([]);
  const [logs, setLogs] = useState<ScanLog[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isResponding, setIsResponding] = useState(false);

  // Sync state with local storage/backend on mount
  useEffect(() => {
    fetchVaultData();
    
    // Seed standard chat history introduction
    setChatHistory([
      {
        id: "intro-1",
        sender: "agent",
        text: "Specialist Researcher is active. I investigate publications and repositories to formulate secure adaptation paths. What autonomous capabilities are we upgrading today?",
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  }, []);

  const fetchVaultData = async () => {
    try {
      const response = await fetch("/api/agent/vault");
      if (response.ok) {
        const data = await response.json();
        setVault(data.vault);
        setLogs(data.logs);
      }
    } catch (e) {
      console.error("Failed to query memory vault state:", e);
    }
  };

  const handleStartScan = async (source: "arxiv" | "medium" | "both", query: string) => {
    setIsScanning(true);
    try {
      const response = await fetch("/api/agent/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source, query })
      });

      if (response.ok) {
        const data = await response.json();
        setVault(prev => [...data.items, ...prev]);
        fetchVaultData();
      } else {
        alert("Scanning failure on server. Check details in logs.");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsScanning(false);
    }
  };

  const handleStartSynthesis = async (ids: string[], instruction: string): Promise<string> => {
    try {
      const response = await fetch("/api/agent/blueprint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ selectedIds: ids, instruction })
      });
      if (response.ok) {
        const data = await response.json();
        return data.report;
      }
      throw new Error("Failed to compile integration roadmap on server.");
    } catch (e) {
      console.error(e);
      return "ERROR: Critical blueprint compilation failure. Please check terminal connection.";
    }
  };

  const handleSendMessage = async (text: string) => {
    const userMessage: ChatMessage = {
      id: Math.random().toString(),
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString()
    };
    setChatHistory(prev => [...prev, userMessage]);
    setIsResponding(true);

    try {
      const response = await fetch("/api/agent/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: text,
          history: chatHistory.slice(-5) // Send some rolling context
        })
      });

      if (response.ok) {
        const data = await response.json();
        const agentMessage: ChatMessage = {
          id: Math.random().toString(),
          sender: "agent",
          text: data.answer,
          timestamp: new Date().toLocaleTimeString()
        };
        setChatHistory(prev => [...prev, agentMessage]);
      } else {
        const errMessage: ChatMessage = {
          id: Math.random().toString(),
          sender: "agent",
          text: "ERROR: Connection interrupted while transmitting cognitive tokens. Let's retry.",
          timestamp: new Date().toLocaleTimeString()
        };
        setChatHistory(prev => [...prev, errMessage]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsResponding(false);
    }
  };

  const handleToggleSelectItem = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <div id="main-container" className="min-h-screen bg-[#020408] text-slate-200 font-sans relative overflow-x-hidden flex flex-col">
      
      {/* Immersive Glow Overlays */}
      <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-indigo-900/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-100px] right-[-100px] w-[600px] h-[600px] bg-indigo-950/10 rounded-full blur-[150px] pointer-events-none" />

      {/* Atmospheric Top Accent Glow */}
      <div className="w-full h-[2px] bg-gradient-to-r from-transparent via-indigo-500/80 to-transparent absolute top-0 left-0" />

      {/* Dynamic Header Banner */}
      <header className="border-b border-white/5 bg-white/5 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo & Identity */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.4)] transition-transform hover:rotate-6">
              <Cpu className="h-5 w-5 text-white stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-bold tracking-tight text-white font-display">
                NEURAL_ARCHIVIST <span className="text-indigo-400 font-mono text-xs ml-1.5 uppercase bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">v0.9.2</span>
              </h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
                Evolutionary Data Acquisition & Synthesis Agent
              </p>
            </div>
          </div>

          {/* Quick System Stats */}
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_10px_#22c55e] animate-pulse"></span>
              <span className="text-emerald-400 font-semibold">CORE SCANNER ACTIVE</span>
            </div>
            <div className="px-3 py-1 border border-white/10 rounded bg-white/5 text-slate-300">
              UPTIME: 124:12:09
            </div>
          </div>

        </div>
      </header>

      {/* Main Responsive Grid Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 z-10">
        
        {/* Left Column: Immersive Source Monitoring Side Drawer / Telemetry (4 columns) */}
        <div className="lg:col-span-4 space-y-6 flex flex-col">
          
          {/* Domain Coverage Card */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex-1 relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 right-0 p-3 opacity-5 pointer-events-none">
              <Database className="w-24 h-24 text-indigo-400" />
            </div>
            
            <div>
              <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-5 flex items-center gap-2">
                <Compass className="h-4 w-4" />
                <span>Target Domain Feeds</span>
              </h3>
              
              <div className="space-y-6">
                {/* arXiv Feed Status */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-white">arxiv.org/list/cs.AI</span>
                    <span className="text-indigo-400">92% Coverage</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full w-[92%] bg-indigo-500 rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]"></div>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal">
                    Latest Pull: "Active self-rewriting logic models in LLMs" <span className="text-slate-400">(14m ago)</span>
                  </p>
                </div>

                {/* Medium tag AI feed status */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-white">medium.com/tag/ai</span>
                    <span className="text-indigo-400">75% Indexed</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full w-[75%] bg-indigo-600 rounded-full shadow-[0_0_10px_rgba(99,102,241,0.4)]"></div>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal">
                    Scraping: "Sandboxing autonomous runtime tools in PyPI" <span className="text-slate-400">(3m ago)</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Micro-threads visualization */}
            <div className="mt-8 pt-6 border-t border-white/5">
              <h4 className="text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-4 font-mono">Telemetry Thread Allocation</h4>
              <div className="grid grid-cols-4 gap-2">
                <div className="h-8 bg-indigo-500/20 border border-indigo-500/30 rounded flex items-center justify-center text-[10px] text-indigo-300 font-mono">TH-01</div>
                <div className="h-8 bg-indigo-500/20 border border-indigo-500/30 rounded flex items-center justify-center text-[10px] text-indigo-300 font-mono">TH-02</div>
                <div className={`h-8 border rounded flex items-center justify-center text-[10px] font-mono transition-colors ${
                  isScanning 
                    ? "bg-indigo-500/60 border-indigo-400 text-white animate-pulse" 
                    : "bg-indigo-500/30 border-indigo-500/40 text-indigo-300"
                }`}>
                  {isScanning ? "SCAN" : "READY"}
                </div>
                <div className="h-8 bg-white/5 border border-white/10 rounded flex items-center justify-center text-[10px] text-slate-500 font-mono">IDLE</div>
              </div>
            </div>
          </div>

          {/* Hardware Stats Graph */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 h-48 flex flex-col justify-between">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-widest font-mono flex items-center gap-1.5">
                <BarChart2 className="h-4 w-4" />
                <span>Cognitive Flow Latency</span>
              </h3>
              <span className="text-[10px] font-mono text-emerald-400">1.2ms Avg</span>
            </div>
            
            {/* Visual Bar Columns */}
            <div className="flex items-end justify-between h-20 gap-1.5 pt-3">
              <div className="w-full bg-indigo-500/20 h-[30%] rounded-t-sm transition-all duration-300"></div>
              <div className="w-full bg-indigo-500/40 h-[45%] rounded-t-sm transition-all duration-300"></div>
              <div className="w-full bg-indigo-500/30 h-[35%] rounded-t-sm transition-all duration-300"></div>
              <div className="w-full bg-indigo-500/50 h-[85%] rounded-t-sm transition-all duration-300"></div>
              <div className={`w-full h-[60%] rounded-t-sm transition-all duration-500 ${isScanning ? "bg-indigo-500/90" : "bg-indigo-500/60"}`}></div>
              <div className="w-full bg-indigo-500/40 h-[70%] rounded-t-sm transition-all duration-300"></div>
              <div className="w-full bg-indigo-500/50 h-[40%] rounded-t-sm transition-all duration-300"></div>
              <div className={`w-full rounded-t-sm transition-all duration-500 ${isScanning ? "bg-indigo-400/100 h-[98%] shadow-[0_0_10px_rgba(99,102,241,0.6)]" : "bg-indigo-500/80 h-[92%]"}`}></div>
              <div className="w-full bg-indigo-500/20 h-[25%] rounded-t-sm transition-all duration-300"></div>
            </div>
            
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>0.0ms</span>
              <span className="uppercase font-semibold text-[8px] text-slate-400">COGNITIVE HARVEST MONITOR</span>
              <span>1.2ms</span>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Knowledge Base (8 columns) */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Main Navigation Tabs Inside Platform */}
          <div className="flex flex-wrap md:flex-nowrap border border-white/10 bg-[#020408]/85 p-1 rounded-xl gap-1">
            <button
              type="button"
              onClick={() => setActiveTab("vault")}
              className={`flex-1 py-3 px-4 rounded-lg font-display text-xs md:text-sm font-semibold transition-all flex items-center justify-center space-x-2 border cursor-pointer ${
                activeTab === "vault"
                  ? "bg-white/5 text-white border-white/10 shadow-[0_0_15px_rgba(99,102,241,0.2)] font-bold"
                  : "text-slate-400 hover:text-slate-200 border-transparent hover:bg-white/2"
              }`}
            >
              <Database className="h-4 w-4 text-indigo-400" />
              <span>Learned Vault</span>
              <span className="text-[10px] font-mono bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded ml-1">
                {vault.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("scanner")}
              className={`flex-1 py-3 px-4 rounded-lg font-display text-xs md:text-sm font-semibold transition-all flex items-center justify-center space-x-2 border cursor-pointer ${
                activeTab === "scanner"
                  ? "bg-white/5 text-white border-white/10 shadow-[0_0_15px_rgba(99,102,241,0.2)] font-bold"
                  : "text-slate-400 hover:text-slate-200 border-transparent hover:bg-white/2"
              }`}
            >
              <Compass className="h-4 w-4 text-indigo-400" />
              <span>Live Search Engine</span>
              {isScanning && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping" />}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("blueprint")}
              className={`flex-1 py-3 px-4 rounded-lg font-display text-xs md:text-sm font-semibold transition-all flex items-center justify-center space-x-2 border cursor-pointer ${
                activeTab === "blueprint"
                  ? "bg-white/5 text-white border-white/10 shadow-[0_0_15px_rgba(99,102,241,0.2)] font-bold"
                  : "text-slate-400 hover:text-slate-200 border-transparent hover:bg-white/2"
              }`}
            >
              <Layers className="h-4 w-4 text-indigo-400" />
              <span>Adaptation Planner</span>
              {selectedIds.length > 0 && (
                <span className="text-[10px] font-mono bg-indigo-500 text-white px-1.5 py-0.5 rounded-full font-bold ml-1">
                  {selectedIds.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("terminal")}
              className={`flex-1 py-3 px-4 rounded-lg font-display text-xs md:text-sm font-semibold transition-all flex items-center justify-center space-x-2 border cursor-pointer ${
                activeTab === "terminal"
                  ? "bg-white/5 text-white border-white/10 shadow-[0_0_15px_rgba(99,102,241,0.2)] font-bold"
                  : "text-slate-400 hover:text-slate-200 border-transparent hover:bg-white/2"
              }`}
            >
              <Terminal className="h-4 w-4 text-indigo-400" />
              <span>AI Specialist CLI</span>
            </button>
          </div>

          {/* Dynamic Tab Panel Container */}
          <div className="bg-white/3 border border-white/10 rounded-2xl p-6 flex-1 min-h-[500px] flex flex-col justify-start relative shadow-2xl backdrop-blur-sm">
            {activeTab === "vault" && (
              <MemoryVault
                vault={vault}
                selectedIds={selectedIds}
                onToggleSelectItem={handleToggleSelectItem}
                onSelectTab={setActiveTab}
              />
            )}

            {activeTab === "scanner" && (
              <ScanConsole
                logs={logs}
                onStartScan={handleStartScan}
                isScanning={isScanning}
                onSelectTab={setActiveTab}
              />
            )}

            {activeTab === "blueprint" && (
              <BlueprintPlanner
                vault={vault}
                selectedIds={selectedIds}
                onStartSynthesis={handleStartSynthesis}
              />
            )}

            {activeTab === "terminal" && (
              <AgentTerminal
                chatHistory={chatHistory}
                onSendMessage={handleSendMessage}
                isResponding={isResponding}
              />
            )}
          </div>

          {/* Bottom Summary Bar mirroring the synthesis vector highlights */}
          <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-2xl p-5 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-1">
                  Active Evolutionary Vectors
                </h3>
                <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
                  These vectors are ready for synthesis in the Adaptation Planner. Select key targets from the Learned Vault above to configure hot-swappable class schemas.
                </p>
              </div>
              <button 
                type="button" 
                onClick={() => setActiveTab("blueprint")}
                className="px-5 py-2 bg-indigo-600 text-white rounded-lg font-bold text-xs shadow-[0_0_20px_rgba(99,102,241,0.3)] hover:bg-indigo-500 hover:shadow-[0_0_30px_rgba(99,102,241,0.5)] transition-all shrink-0 cursor-pointer"
              >
                COMPILE AND PLAN LOGIC
              </button>
            </div>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="flex items-center gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                <span className="text-[10px] text-indigo-200/70 font-mono">Dynamic Node Injection</span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                <span className="text-[10px] text-indigo-200/70 font-mono">AST-Shield Program Sanity</span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                <span className="text-[10px] text-indigo-200/70 font-mono">Variational Active Inference</span>
              </div>
            </div>
            <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent"></div>
          </div>

        </div>

      </main>

      {/* Footer Bar */}
      <footer className="px-8 py-5 bg-black/50 border-t border-white/5 flex flex-col md:flex-row items-center justify-between text-[10px] font-mono tracking-tighter text-slate-500 gap-4 z-10 shrink-0 mt-auto">
        <div className="text-left max-w-3xl leading-snug">
          SYSTEM LOG: [12:44:21] - Searching arXiv for Agent Framework updates... [12:45:01] - Instantiating Gemini metadata chunks... [12:45:12] - Code sandbox generation pipeline: ARX_SYS_READY
        </div>
        <div className="flex gap-4">
          <span className="text-indigo-400">SECURE CONSOLE: LOCALHOST:3000</span>
          <span className="text-slate-700">|</span>
          <span className="text-slate-400">SECURITY PROTOCOL: AST-SHIELD DIRECTIVE</span>
        </div>
      </footer>
    </div>
  );
}
