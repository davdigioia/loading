export interface LearnedItem {
  id: string;
  title: string;
  authors: string;
  source: "arXiv" | "Medium";
  date: string;
  url: string;
  keyBreakthrough: string;
  pythonLibrary: string;
  evolutionMechanics: string;
  adaptationBlueprint: string;
  integrationCode: string;
}

export interface ScanLog {
  timestamp: string;
  level: "INFO" | "WARN" | "SUCCESS";
  message: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "agent";
  text: string;
  timestamp: string;
}

export type ActiveTab = "vault" | "scanner" | "blueprint" | "terminal";
