"""
wire_into_native_adapters.py
=============================
Shows exactly how to replace the two fake methods from native_adapters.py
with real ones. Copy these method bodies into your actual class — this file
is the patch, written so the diff is obvious.

BEFORE (fake):
    def execute_code_plan(self, plan, data):
        ...
        return {"ok": True, "code": code, ...}          # never ran it
        return {"ok": True, "code": self._fallback_code(...), ...}  # stub

    def extract_execution_trace(self, result):
        return {"ok": bool(result.get("ok", False)),
                 "has_code": bool(result.get("code")), ...}   # not a real signal

AFTER (real, below): execute_code_plan actually runs the code in
safe_execution.run_python via the self-repair loop, and
extract_execution_trace reports real stdout/stderr/traceback/exit_code.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from codegen_loop import run_codegen_with_self_repair, CodegenRunReport
from llm_providers import LLMProvider, get_default_provider
from safe_execution import ResourceLimits


class RealCodegenMixin:
    """
    Mix this into (or copy these two methods into) the adapter class that
    currently has the fake execute_code_plan / extract_execution_trace.

    Expects `self` to optionally have:
      - self.llm_provider: an LLMProvider (falls back to env-based default)
      - self.native_codegen_max_attempts: int (default 5)
      - self.native_codegen_timeout_seconds: float (default 10.0)
    """

    llm_provider: Optional[LLMProvider] = None
    native_codegen_max_attempts: int = 5
    native_codegen_timeout_seconds: float = 10.0

    def execute_code_plan(self, plan: Dict[str, Any], data: Any) -> Dict[str, Any]:
        """
        Real replacement. `plan` is expected to carry at least a `query`
        (the task description) and optionally `language` (only "python" is
        executed for real right now — see note at bottom of file) and
        `seed_code` if a draft already exists.
        """
        query = plan.get("query", "")
        language = plan.get("language", "python")
        seed_code = plan.get("seed_code")

        if language != "python":
            # Be honest instead of silently returning a fake success for
            # languages this engine doesn't actually execute.
            return {
                "ok": False,
                "code": None,
                "error": f"language '{language}' is not yet wired to a real "
                         f"execution backend; only python is supported.",
                "report": None,
            }

        provider = self.llm_provider or get_default_provider()

        report: CodegenRunReport = run_codegen_with_self_repair(
            task=query,
            provider=provider,
            max_attempts=self.native_codegen_max_attempts,
            limits=ResourceLimits(timeout_seconds=self.native_codegen_timeout_seconds),
            seed_code=seed_code,
        )

        return {
            "ok": report.ok,                       # <- now means "really ran"
            "code": report.final_code,
            "stdout": report.final_result.stdout if report.final_result else "",
            "stderr": report.final_result.stderr if report.final_result else "",
            "traceback": report.final_result.traceback if report.final_result else None,
            "num_attempts": len(report.attempts),
            "summary": report.summary(),
            "report": report.to_dict(),            # full history for debugging/audit
        }

    def extract_execution_trace(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Real replacement. Surfaces actual execution signals instead of just
        `has_code`. Downstream verifiers can now check real outcomes.
        """
        return {
            "ok": bool(result.get("ok", False)),
            "has_code": bool(result.get("code")),
            "ran": result.get("report") is not None,
            "exit_code": (
                result.get("report", {})
                .get("final_result", {})
                .get("exit_code")
                if result.get("report") else None
            ),
            "stdout": result.get("stdout", ""),
            "stderr": result.get("stderr", ""),
            "traceback": result.get("traceback"),
            "num_attempts": result.get("num_attempts", 0),
            "wall_time_seconds": (
                result.get("report", {})
                .get("final_result", {})
                .get("wall_time_seconds")
                if result.get("report") else None
            ),
        }


# Note on multi-language: the original code path had `language` as a field
# but only ever produced a markdown fence — nothing executed non-Python
# code either. Wiring a second real backend (e.g. Node via subprocess with
# the same ResourceLimits pattern) is mechanical: write a run_javascript()
# in safe_execution.py mirroring run_python(), then branch on `language`
# above. Left out here because you only asked about Python; ask if you want
# JS/other languages wired the same way.
