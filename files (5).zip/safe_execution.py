"""
safe_execution.py
==================
The missing piece: an execution engine that actually RUNS Python code,
instead of returning a string and calling it "ok".

Design goals (in priority order):
  1. Never silently lie about success. "ok" means "ran, exit 0, no traceback."
  2. Isolate the child process: separate interpreter, restricted resources,
     restricted builtins/imports, no network by default, scratch CWD.
  3. Capture everything needed to fix the code on the next loop: stdout,
     stderr, the exact traceback, exit code, wall time, and which resource
     limit (if any) was hit.
  4. Be honest about what this is NOT: this is OS-level process isolation
     with resource caps, not a hardened multi-tenant sandbox like gVisor or
     Firecracker. If you are running untrusted code from strangers on the
     internet, put this behind a container/VM boundary too. For an agent
     fixing its own generated code on a trusted single-user machine, this
     is the right amount of isolation.

No third-party dependencies. Stdlib only: subprocess, resource, tempfile,
ast, signal, os, sys, json, time, textwrap, dataclasses.
"""

from __future__ import annotations

import ast
import dataclasses
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import tempfile
import textwrap
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

#: Modules allowed to be imported by executed code. Anything not in this set
#: (or a submodule of something in this set) is rejected at static-analysis
#: time, before the process is ever spawned. Edit this list to taste.
DEFAULT_IMPORT_ALLOWLIST: frozenset[str] = frozenset({
    # stdlib: data & math
    "math", "statistics", "random", "decimal", "fractions", "itertools",
    "functools", "collections", "heapq", "bisect", "array", "cmath",
    # stdlib: text & data formats
    "re", "json", "csv", "string", "textwrap", "unicodedata", "difflib",
    # stdlib: datetime
    "datetime", "time", "calendar",
    # stdlib: misc safe utilities
    "copy", "typing", "dataclasses", "enum", "abc", "operator", "uuid",
    "hashlib", "base64", "binascii",
    # stdlib: io that is sandbox-safe (no arbitrary filesystem outside CWD
    # is enforced by the *runtime* limits below, not by blocking the import)
    "io",
    # sys: needed for stdin/stdout/argv (pipeline-mode scripts read
    # sys.stdin; this does NOT grant process/exec control — that's os/
    # subprocess, which stay denylisted below)
    "sys",
    # common third-party data/sci stack — only usable if actually installed
    # in the execution environment; missing imports just fail normally
    "numpy", "pandas", "matplotlib", "scipy", "sympy",
})

#: Modules that are explicitly never allowed, regardless of allowlist edits,
#: because they grant direct OS/network/process control. This is a denylist
#: that wins even if someone adds "os" to the allowlist above by mistake.
HARD_DENYLIST: frozenset[str] = frozenset({
    "os", "subprocess", "shutil", "socket", "ctypes", "multiprocessing",
    "threading", "asyncio", "signal", "resource", "pty", "pdb", "code",
    "importlib", "pkgutil", "runpy", "pickle", "marshal", "shelve",
})


@dataclasses.dataclass
class ResourceLimits:
    """Caps applied to the child process via the `resource` module + a wall
    clock timeout enforced by the parent. All limits are soft defaults you
    can override per-call."""
    timeout_seconds: float = 10.0
    max_memory_mb: int = 512
    max_cpu_seconds: int = 10
    max_output_bytes: int = 1_000_000          # stdout+stderr combined cap
    max_file_size_mb: int = 16                 # any single file written
    max_open_files: int = 64
    allow_network: bool = False                # informational; see notes


@dataclasses.dataclass
class ExecutionResult:
    """Ground truth about what happened when code ran. This struct is what
    extract_execution_trace should have been returning all along — real
    signals, not just `has_code`."""
    ok: bool
    exit_code: Optional[int]
    stdout: str
    stderr: str
    traceback: Optional[str]
    timed_out: bool
    killed_reason: Optional[str]            # e.g. "memory_limit", "timeout"
    wall_time_seconds: float
    static_check_error: Optional[str]       # set if code never even ran
    artifacts: List[str] = dataclasses.field(default_factory=list)  # files written

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    @property
    def error_summary(self) -> Optional[str]:
        """A single string suitable for feeding back into an LLM prompt as
        'here is what went wrong, fix it'."""
        if self.ok:
            return None
        if self.static_check_error:
            return f"Static check failed before execution: {self.static_check_error}"
        if self.timed_out:
            return f"Execution timed out after {self.wall_time_seconds:.1f}s."
        if self.killed_reason:
            return f"Process was killed: {self.killed_reason}."
        if self.traceback:
            return self.traceback
        if self.exit_code not in (0, None):
            return f"Process exited with code {self.exit_code}. stderr:\n{self.stderr}"
        return "Unknown failure."


class StaticSafetyError(Exception):
    """Raised when code fails the pre-execution static safety check."""


# --------------------------------------------------------------------------
# Static safety check (runs BEFORE we ever spawn a process)
# --------------------------------------------------------------------------

def static_safety_check(
    code: str,
    import_allowlist: frozenset[str] = DEFAULT_IMPORT_ALLOWLIST,
    local_modules: frozenset[str] = frozenset(),
) -> Optional[str]:
    """
    Parse the code with `ast` and reject anything that imports a
    disallowed/denylisted module, or uses exec/eval/__import__ to dodge the
    import check dynamically. Returns an error string, or None if clean.

    `local_modules`: module names that are actually sibling files within
    the same workspace (e.g. {"helper"} if helper.py sits next to the file
    being checked). These are real local imports, not third-party packages,
    so they're allowed regardless of import_allowlist — the workspace
    runner controls what files exist, the same way it controls what code
    runs.

    This is defense-in-depth, not the only line of defense — the resource
    limits below are what actually contain a process that gets past this.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SyntaxError during static check: {e}"

    forbidden_calls = {"exec", "eval", "__import__", "compile"}

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root in local_modules:
                    continue
                if root in HARD_DENYLIST:
                    return f"Import of '{alias.name}' is denylisted."
                if root not in import_allowlist:
                    return f"Import of '{alias.name}' is not in the allowlist."
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root in local_modules:
                continue
            if root in HARD_DENYLIST:
                return f"Import of '{node.module}' is denylisted."
            if root and root not in import_allowlist:
                return f"Import of '{node.module}' is not in the allowlist."
        elif isinstance(node, ast.Call):
            fn = node.func
            name = fn.id if isinstance(fn, ast.Name) else getattr(fn, "attr", None)
            if name in forbidden_calls:
                return f"Use of '{name}()' is not allowed in sandboxed code."

    return None


# --------------------------------------------------------------------------
# The child-process bootstrap
# --------------------------------------------------------------------------

_CHILD_BOOTSTRAP = r"""
import resource, sys, os, faulthandler

def _apply_limits(max_mem_bytes, max_cpu_seconds, max_file_bytes, max_open_files):
    try:
        resource.setrlimit(resource.RLIMIT_AS, (max_mem_bytes, max_mem_bytes))
    except Exception:
        pass
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (max_cpu_seconds, max_cpu_seconds))
    except Exception:
        pass
    try:
        resource.setrlimit(resource.RLIMIT_FSIZE, (max_file_bytes, max_file_bytes))
    except Exception:
        pass
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE, (max_open_files, max_open_files))
    except Exception:
        pass
    try:
        resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))
    except Exception:
        pass

if __name__ == "__main__":
    _apply_limits(
        int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    )
    faulthandler.enable()
    user_file = sys.argv[5]
    # -I (isolated mode) intentionally drops the script directory from
    # sys.path for environment hygiene (no accidental PYTHONPATH/site
    # pickup). That also blocks legitimate sibling-file imports in a real
    # multi-file workspace, so we explicitly re-add only the sandboxed
    # workdir itself — not the real filesystem, not site-packages beyond
    # what -I already permits.
    sys.path.insert(0, os.path.dirname(os.path.abspath(user_file)) or ".")
    sys.argv = [user_file] + sys.argv[6:]
    with open(user_file, "r") as f:
        src = f.read()
    code_obj = compile(src, user_file, "exec")
    exec(code_obj, {"__name__": "__main__", "__file__": user_file})
"""


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

def run_python(
    code: str,
    *,
    limits: Optional[ResourceLimits] = None,
    extra_files: Optional[Dict[str, str]] = None,
    entrypoint: Optional[str] = None,
    import_allowlist: frozenset[str] = DEFAULT_IMPORT_ALLOWLIST,
    cli_args: Optional[Sequence[str]] = None,
    stdin_data: Optional[str] = None,
) -> ExecutionResult:
    """
    Run `code` as a standalone Python script in an isolated subprocess.

    Parameters
    ----------
    code: the Python source to run (used directly unless `entrypoint` is set)
    limits: ResourceLimits; defaults applied if not given
    extra_files: {relative_path: content} written into the scratch dir first,
                 enabling multi-file projects (see CodeWorkspace below)
    entrypoint: if set, this file (already among extra_files, or "main.py"
                if code is the entrypoint) is what actually gets executed;
                `code` is then written to that path
    import_allowlist: override the default allowed-imports set
    cli_args: argv passed to the script
    stdin_data: text piped into the process's real stdin (used by pipeline
                mode in workspace.py to chain real subprocess stdout/stdin)

    Returns
    -------
    ExecutionResult with real ok/stdout/stderr/traceback — never a stub.
    """
    limits = limits or ResourceLimits()
    extra_files = extra_files or {}
    start = time.time()

    # Sibling .py files (minus their extension) are legitimate local
    # imports, not third-party packages — recognize them so multi-file
    # projects can import each other without tripping the allowlist.
    local_modules = frozenset(
        Path(rel_path).stem for rel_path in extra_files if rel_path.endswith(".py")
    )

    static_err = static_safety_check(code, import_allowlist, local_modules=local_modules)
    if static_err:
        return ExecutionResult(
            ok=False, exit_code=None, stdout="", stderr="",
            traceback=None, timed_out=False, killed_reason=None,
            wall_time_seconds=0.0, static_check_error=static_err,
        )
    # Also check any extra files that will be imported. Each file's check
    # includes itself minus the other files as valid local-import targets.
    for rel_path, content in extra_files.items():
        if rel_path.endswith(".py"):
            siblings = local_modules  # a file may import any other sibling
            err = static_safety_check(content, import_allowlist, local_modules=siblings)
            if err:
                return ExecutionResult(
                    ok=False, exit_code=None, stdout="", stderr="",
                    traceback=None, timed_out=False, killed_reason=None,
                    wall_time_seconds=0.0,
                    static_check_error=f"{rel_path}: {err}",
                )

    workdir = Path(tempfile.mkdtemp(prefix=f"sandbox_{uuid.uuid4().hex[:8]}_"))
    try:
        entry_name = entrypoint or "main.py"
        (workdir / entry_name).write_text(code)
        for rel_path, content in extra_files.items():
            target = workdir / rel_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content)

        bootstrap_path = workdir / "_bootstrap.py"
        bootstrap_path.write_text(_CHILD_BOOTSTRAP)

        cmd = [
            sys.executable, "-I",          # isolated mode: ignore env/site customizations
            str(bootstrap_path),
            str(limits.max_memory_mb * 1024 * 1024),
            str(limits.max_cpu_seconds),
            str(limits.max_file_size_mb * 1024 * 1024),
            str(limits.max_open_files),
            entry_name,
            *(cli_args or []),
        ]

        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONIOENCODING": "utf-8",
        }
        if limits.allow_network:
            # Note: this process-level flag does NOT itself block network
            # access — true network denial needs a namespace/firewall layer
            # outside Python's control. Treat allow_network=False as "we did
            # not grant credentials/proxies", not as a network kill switch.
            pass

        timed_out = False
        killed_reason = None
        stdin_bytes = stdin_data.encode("utf-8") if stdin_data is not None else None
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(workdir),
                env=env,
                input=stdin_bytes,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=limits.timeout_seconds,
            )
            stdout = proc.stdout.decode("utf-8", errors="replace")
            stderr = proc.stderr.decode("utf-8", errors="replace")
            exit_code = proc.returncode
        except subprocess.TimeoutExpired as e:
            timed_out = True
            killed_reason = "timeout"
            stdout = (e.stdout or b"").decode("utf-8", errors="replace")
            stderr = (e.stderr or b"").decode("utf-8", errors="replace")
            exit_code = None

        # Truncate pathological output
        if len(stdout) > limits.max_output_bytes:
            stdout = stdout[: limits.max_output_bytes] + "\n...[stdout truncated]"
        if len(stderr) > limits.max_output_bytes:
            stderr = stderr[: limits.max_output_bytes] + "\n...[stderr truncated]"

        if not timed_out and exit_code not in (0, None) and exit_code < 0:
            # Negative returncode means killed by signal (e.g. SIGKILL from
            # cgroup OOM, or SIGSEGV, or SIGXFSZ from RLIMIT_FSIZE).
            sig = -exit_code
            killed_reason = {
                getattr(signal, "SIGKILL", 9): "memory_limit_or_oom",
                getattr(signal, "SIGXFSZ", 25): "file_size_limit",
                getattr(signal, "SIGSEGV", 11): "segfault",
                getattr(signal, "SIGXCPU", 24): "cpu_time_limit",
            }.get(sig, f"signal_{sig}")

        traceback_text = _extract_traceback(stderr) if exit_code not in (0, None) else None
        ok = (exit_code == 0) and not timed_out

        # RLIMIT_AS often surfaces as a normal catchable MemoryError (exit 1
        # with a traceback) rather than a kill signal. Label it accurately
        # so callers don't have to guess from the traceback text themselves.
        if not ok and not killed_reason and traceback_text and "MemoryError" in traceback_text:
            killed_reason = "memory_limit"

        artifacts = []
        for p in workdir.rglob("*"):
            if p.is_file() and p.name not in (entry_name, "_bootstrap.py") and p.name not in extra_files:
                artifacts.append(str(p.relative_to(workdir)))

        return ExecutionResult(
            ok=ok,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            traceback=traceback_text,
            timed_out=timed_out,
            killed_reason=killed_reason,
            wall_time_seconds=time.time() - start,
            static_check_error=None,
            artifacts=artifacts,
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _extract_traceback(stderr: str) -> Optional[str]:
    """Pull the Python traceback out of stderr, if present."""
    if "Traceback (most recent call last):" in stderr:
        idx = stderr.index("Traceback (most recent call last):")
        return stderr[idx:].strip()
    if stderr.strip():
        return stderr.strip()
    return None
