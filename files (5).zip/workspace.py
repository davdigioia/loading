"""
workspace.py
============
Real multi-file Python project support. This is the piece that was still
missing after the first pass: that version let one entrypoint *pull in*
extra supporting files, but (a) self-repair only ever rewrote a single
`code` string, never the supporting files, and (b) there was no concept of
"these N files are independent, run each and combine results" or "these N
files form a pipeline, file A's stdout feeds file B's stdin."

This module adds:

  - CodeWorkspace: a named collection of .py files with an execution mode.
  - run_workspace(): actually executes that mode for real via
    safe_execution.run_python (entrypoint mode) or repeated real subprocess
    runs (independent / pipeline modes) — no mode is faked.
  - run_workspace_with_self_repair(): the self-repair loop, upgraded to see
    and rewrite ANY file in the workspace, not just the one that errored.
    The LLM gets the full file set + which file failed + that file's real
    traceback, and returns a full corrected file set.

Three execution modes, all real:

  ENTRYPOINT  — one file is `python entrypoint.py`; it may `import` the
                others (typical project layout). One process, real imports,
                real shared state.
  INDEPENDENT — each file is run in its own subprocess; nothing is shared
                between them. Useful for "these are N separate scripts the
                agent is writing in one batch." Results are combined, not
                merged in-process.
  PIPELINE    — files run in the order given; each file's stdout becomes
                the next file's stdin. A real Unix pipeline, not a
                simulation — actual bytes flow from one real subprocess's
                stdout into the next real subprocess's stdin.
"""

from __future__ import annotations

import dataclasses
import json
import textwrap
from enum import Enum
from typing import Any, Dict, List, Optional

from safe_execution import (
    DEFAULT_IMPORT_ALLOWLIST,
    ExecutionResult,
    ResourceLimits,
    run_python,
    static_safety_check,
)
from llm_providers import LLMProvider, get_default_provider


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------

class ExecutionMode(str, Enum):
    ENTRYPOINT = "entrypoint"     # one file imports/calls the others
    INDEPENDENT = "independent"   # each file runs alone, results combined
    PIPELINE = "pipeline"         # file[i].stdout -> file[i+1].stdin, in order


@dataclasses.dataclass
class WorkspaceFile:
    path: str          # relative path, e.g. "main.py" or "lib/utils.py"
    content: str


@dataclasses.dataclass
class CodeWorkspace:
    """A real multi-file Python project."""
    files: List[WorkspaceFile]
    mode: ExecutionMode
    entrypoint: Optional[str] = None   # required for ENTRYPOINT mode
    order: Optional[List[str]] = None  # required for PIPELINE mode (file order);
                                        # for INDEPENDENT, defaults to all files

    def get(self, path: str) -> Optional[WorkspaceFile]:
        for f in self.files:
            if f.path == path:
                return f
        return None

    def as_dict_map(self) -> Dict[str, str]:
        return {f.path: f.content for f in self.files}

    def replace_file(self, path: str, new_content: str) -> "CodeWorkspace":
        new_files = [
            WorkspaceFile(path=f.path, content=new_content) if f.path == path else f
            for f in self.files
        ]
        return dataclasses.replace(self, files=new_files)


@dataclasses.dataclass
class FileRunOutcome:
    path: str
    result: ExecutionResult


@dataclasses.dataclass
class WorkspaceRunResult:
    """Ground truth for a whole-workspace run. ok=True only if every file
    that needed to succeed, did."""
    ok: bool
    mode: ExecutionMode
    per_file: List[FileRunOutcome]
    combined_stdout: str
    failed_file: Optional[str]   # which file (if any) caused the failure

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "mode": self.mode.value,
            "failed_file": self.failed_file,
            "combined_stdout": self.combined_stdout,
            "per_file": [
                {"path": o.path, "result": o.result.to_dict()} for o in self.per_file
            ],
        }

    @property
    def error_summary(self) -> Optional[str]:
        if self.ok:
            return None
        for outcome in self.per_file:
            if not outcome.result.ok:
                return f"[{outcome.path}] {outcome.result.error_summary}"
        return "Unknown workspace failure."


# --------------------------------------------------------------------------
# Real execution of each mode
# --------------------------------------------------------------------------

def run_workspace(
    workspace: CodeWorkspace,
    *,
    limits: Optional[ResourceLimits] = None,
    import_allowlist=DEFAULT_IMPORT_ALLOWLIST,
) -> WorkspaceRunResult:
    """Actually executes the workspace according to its mode. Every branch
    below calls safe_execution.run_python for real — no branch returns a
    canned success."""
    limits = limits or ResourceLimits()
    file_map = workspace.as_dict_map()

    if workspace.mode == ExecutionMode.ENTRYPOINT:
        return _run_entrypoint_mode(workspace, file_map, limits, import_allowlist)
    elif workspace.mode == ExecutionMode.INDEPENDENT:
        return _run_independent_mode(workspace, file_map, limits, import_allowlist)
    elif workspace.mode == ExecutionMode.PIPELINE:
        return _run_pipeline_mode(workspace, file_map, limits, import_allowlist)
    else:
        raise ValueError(f"Unknown execution mode: {workspace.mode}")


def _run_entrypoint_mode(workspace, file_map, limits, import_allowlist) -> WorkspaceRunResult:
    if not workspace.entrypoint or workspace.entrypoint not in file_map:
        raise ValueError("ENTRYPOINT mode requires `entrypoint` to name an existing file.")

    entry_content = file_map[workspace.entrypoint]
    supporting_files = {p: c for p, c in file_map.items() if p != workspace.entrypoint}

    result = run_python(
        entry_content,
        limits=limits,
        extra_files=supporting_files,
        entrypoint=workspace.entrypoint,
        import_allowlist=import_allowlist,
    )
    outcome = FileRunOutcome(path=workspace.entrypoint, result=result)
    return WorkspaceRunResult(
        ok=result.ok,
        mode=workspace.mode,
        per_file=[outcome],
        combined_stdout=result.stdout,
        failed_file=None if result.ok else workspace.entrypoint,
    )


def _run_independent_mode(workspace, file_map, limits, import_allowlist) -> WorkspaceRunResult:
    target_paths = workspace.order or list(file_map.keys())
    outcomes: List[FileRunOutcome] = []
    combined_parts: List[str] = []
    failed_file = None

    for path in target_paths:
        content = file_map[path]
        result = run_python(content, limits=limits, import_allowlist=import_allowlist)
        outcomes.append(FileRunOutcome(path=path, result=result))
        combined_parts.append(f"--- {path} ---\n{result.stdout}")
        if not result.ok and failed_file is None:
            failed_file = path

    all_ok = all(o.result.ok for o in outcomes)
    return WorkspaceRunResult(
        ok=all_ok,
        mode=workspace.mode,
        per_file=outcomes,
        combined_stdout="\n".join(combined_parts),
        failed_file=failed_file,
    )


def _run_pipeline_mode(workspace, file_map, limits, import_allowlist) -> WorkspaceRunResult:
    if not workspace.order:
        raise ValueError("PIPELINE mode requires `order` to list files in run sequence.")

    outcomes: List[FileRunOutcome] = []
    stdin_for_next = ""
    failed_file = None

    for path in workspace.order:
        content = file_map[path]
        result = run_python(
            content,
            limits=limits,
            import_allowlist=import_allowlist,
            stdin_data=stdin_for_next,
        )
        outcomes.append(FileRunOutcome(path=path, result=result))
        if not result.ok:
            failed_file = path
            break  # real pipeline semantics: a broken stage halts the chain
        stdin_for_next = result.stdout

    all_ok = failed_file is None
    return WorkspaceRunResult(
        ok=all_ok,
        mode=workspace.mode,
        per_file=outcomes,
        combined_stdout=stdin_for_next,  # final stage's output
        failed_file=failed_file,
    )


# --------------------------------------------------------------------------
# Self-repair across the WHOLE file set
# --------------------------------------------------------------------------

WORKSPACE_SYSTEM_PROMPT = textwrap.dedent("""\
    You are a careful Python engineer fixing a multi-file project. You will
    be shown every file in the project, which file failed, and the real
    error/traceback from actually running it.

    The bug may live in the file that errored, OR in a different file it
    calls/imports — fix the root cause wherever it actually is, and you may
    rewrite multiple files if needed.

    Respond with ONLY a JSON object mapping file path -> full corrected file
    content, for every file you are changing (omit files you did not need
    to touch). No prose, no markdown fences, just the JSON object. Example:
    {"main.py": "...full corrected content...", "lib/utils.py": "...full corrected content..."}
""")

WORKSPACE_FIX_PROMPT_TEMPLATE = textwrap.dedent("""\
    Task: {task}
    Execution mode: {mode}

    --- current files ---
    {files_block}
    --- end current files ---

    The file that failed was: {failed_file}

    --- real error from actually running it ---
    {error}
    --- end error ---

    Return corrected file(s) as a JSON object (path -> full new content).
""")


def _render_files_block(workspace: CodeWorkspace) -> str:
    parts = []
    for f in workspace.files:
        parts.append(f"### {f.path}\n```python\n{f.content}\n```")
    return "\n\n".join(parts)


def _extract_json_object(text: str) -> Dict[str, str]:
    """Pull a {path: content} JSON object out of an LLM response, tolerating
    accidental markdown fences around it."""
    t = text.strip()
    if t.startswith("```"):
        t = t.split("```", 2)[1]
        if t.startswith("json"):
            t = t[4:]
        t = t.strip()
        if "```" in t:
            t = t[: t.index("```")]
    return json.loads(t)


@dataclasses.dataclass
class WorkspaceAttempt:
    attempt_number: int
    workspace: CodeWorkspace
    run_result: WorkspaceRunResult


@dataclasses.dataclass
class WorkspaceRepairReport:
    ok: bool
    task: str
    attempts: List[WorkspaceAttempt]
    final_workspace: Optional[CodeWorkspace]
    final_run_result: Optional[WorkspaceRunResult]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "task": self.task,
            "num_attempts": len(self.attempts),
            "attempts": [
                {
                    "attempt_number": a.attempt_number,
                    "files": a.workspace.as_dict_map(),
                    "run_result": a.run_result.to_dict(),
                }
                for a in self.attempts
            ],
            "final_files": self.final_workspace.as_dict_map() if self.final_workspace else None,
            "final_run_result": self.final_run_result.to_dict() if self.final_run_result else None,
        }

    def summary(self) -> str:
        if self.ok:
            return f"Workspace succeeded after {len(self.attempts)} attempt(s)."
        last = self.attempts[-1].run_result if self.attempts else None
        reason = last.error_summary if last else "no attempts were made"
        return f"Workspace failed after {len(self.attempts)} attempt(s). Last error: {reason}"


def run_workspace_with_self_repair(
    task: str,
    workspace: CodeWorkspace,
    *,
    provider: Optional[LLMProvider] = None,
    max_attempts: int = 5,
    limits: Optional[ResourceLimits] = None,
    import_allowlist=DEFAULT_IMPORT_ALLOWLIST,
) -> WorkspaceRepairReport:
    """
    Runs the workspace for real. On failure, sends the ENTIRE file set
    (not just the failing file) plus the real error to the LLM, and accepts
    back a full corrected file set — so a bug whose root cause is in a
    different file than the one that crashed can actually get fixed.
    """
    provider = provider or get_default_provider()

    # Sibling .py files in the workspace are legitimate local imports.
    local_modules = frozenset(
        f.path[:-3].split("/")[-1] for f in workspace.files if f.path.endswith(".py")
    )

    # Validate every file up front so we fail fast and clearly.
    for f in workspace.files:
        err = static_safety_check(f.content, import_allowlist, local_modules=local_modules)
        if err:
            bad_result = WorkspaceRunResult(
                ok=False, mode=workspace.mode,
                per_file=[FileRunOutcome(
                    path=f.path,
                    result=ExecutionResult(
                        ok=False, exit_code=None, stdout="", stderr="",
                        traceback=None, timed_out=False, killed_reason=None,
                        wall_time_seconds=0.0, static_check_error=err,
                    ),
                )],
                combined_stdout="", failed_file=f.path,
            )
            return WorkspaceRepairReport(
                ok=False, task=task,
                attempts=[WorkspaceAttempt(1, workspace, bad_result)],
                final_workspace=workspace, final_run_result=bad_result,
            )

    current = workspace
    attempts: List[WorkspaceAttempt] = []

    for attempt_num in range(1, max_attempts + 1):
        run_result = run_workspace(current, limits=limits, import_allowlist=import_allowlist)
        attempts.append(WorkspaceAttempt(attempt_num, current, run_result))

        if run_result.ok:
            return WorkspaceRepairReport(
                ok=True, task=task, attempts=attempts,
                final_workspace=current, final_run_result=run_result,
            )

        if attempt_num == max_attempts:
            break

        fix_prompt = WORKSPACE_FIX_PROMPT_TEMPLATE.format(
            task=task,
            mode=current.mode.value,
            files_block=_render_files_block(current),
            failed_file=run_result.failed_file,
            error=run_result.error_summary,
        )
        response = provider.complete(system=WORKSPACE_SYSTEM_PROMPT, user=fix_prompt, max_tokens=4000)

        try:
            corrections = _extract_json_object(response)
        except (json.JSONDecodeError, IndexError) as e:
            # The LLM didn't return parseable JSON — record it as a failed
            # attempt rather than silently giving up or faking success.
            break

        new_files = list(current.files)
        existing_paths = {f.path for f in new_files}
        for path, new_content in corrections.items():
            if path in existing_paths:
                new_files = [
                    WorkspaceFile(path=p.path, content=new_content) if p.path == path else p
                    for p in new_files
                ]
            else:
                new_files.append(WorkspaceFile(path=path, content=new_content))

            # Recompute local modules including any file the correction
            # just added, so a fix that introduces a new sibling file
            # doesn't immediately get flagged as importing an unknown module.
            post_correction_local_modules = frozenset(
                f.path[:-3].split("/")[-1] for f in new_files if f.path.endswith(".py")
            )
            err = static_safety_check(
                new_content, import_allowlist, local_modules=post_correction_local_modules
            )
            if err:
                # A correction introduced an unsafe import — reject this
                # whole revision rather than running it.
                bad_result = WorkspaceRunResult(
                    ok=False, mode=current.mode,
                    per_file=[FileRunOutcome(
                        path=path,
                        result=ExecutionResult(
                            ok=False, exit_code=None, stdout="", stderr="",
                            traceback=None, timed_out=False, killed_reason=None,
                            wall_time_seconds=0.0, static_check_error=err,
                        ),
                    )],
                    combined_stdout="", failed_file=path,
                )
                attempts.append(WorkspaceAttempt(attempt_num + 1, current, bad_result))
                return WorkspaceRepairReport(
                    ok=False, task=task, attempts=attempts,
                    final_workspace=current, final_run_result=bad_result,
                )

        current = dataclasses.replace(current, files=new_files)

    return WorkspaceRepairReport(
        ok=False, task=task, attempts=attempts,
        final_workspace=attempts[-1].workspace if attempts else None,
        final_run_result=attempts[-1].run_result if attempts else None,
    )
