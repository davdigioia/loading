# Real Code Execution Engine

Replaces the fake `execute_code_plan` / `extract_execution_trace` with code
that actually runs Python, captures real errors, and retries with the
traceback fed back to the LLM until it genuinely works (or honestly fails)
— including real multi-file projects.

## Files

| File | Purpose |
|---|---|
| `safe_execution.py` | Runs Python in an isolated subprocess: timeout, memory/CPU/file-size caps, import allowlist + denylist, real stdout/stderr/traceback capture, real stdin piping. No third-party deps. |
| `llm_providers.py` | Pluggable interface for the LLM that generates/fixes code. Ships with Anthropic, OpenAI, generic OpenAI-compatible (local models/Groq/etc), and a labeled stub. Auto-picks based on whichever API key is in your environment. |
| `codegen_loop.py` | Single-file generate → run → fail → feed traceback back → regenerate loop. Default 5 attempts. |
| `workspace.py` | **Multi-file project support.** `CodeWorkspace` holds N `.py` files in one of three real execution modes (entrypoint / independent / pipeline). Self-repair sees and can rewrite *any* file in the set, not just the one that crashed. |
| `wire_into_native_adapters.py` | The exact patch for your existing fake methods — copy these two method bodies in. |
| `test_self_repair.py` | Proves the single-file loop works using a scripted fake LLM. |
| `test_workspace_repair.py` | Proves multi-file self-repair works, including the case that matters most: bug crashes in file A, real defect is in file B, fix correctly lands in B (or both). |

## Multi-file execution modes (`workspace.py`)

```python
from workspace import CodeWorkspace, WorkspaceFile, ExecutionMode, run_workspace_with_self_repair

# ENTRYPOINT — one file imports/calls the others (normal project layout)
ws = CodeWorkspace(
    files=[
        WorkspaceFile("main.py", "from helper import double\nprint(double(21))"),
        WorkspaceFile("helper.py", "def double(x):\n    return x * 2"),
    ],
    mode=ExecutionMode.ENTRYPOINT,
    entrypoint="main.py",
)

# INDEPENDENT — each file runs in its own subprocess, results combined
ws = CodeWorkspace(
    files=[WorkspaceFile("a.py", "..."), WorkspaceFile("b.py", "...")],
    mode=ExecutionMode.INDEPENDENT,
)

# PIPELINE — real stdout -> stdin chaining across real subprocesses, in order
ws = CodeWorkspace(
    files=[WorkspaceFile("stage1.py", "..."), WorkspaceFile("stage2.py", "...")],
    mode=ExecutionMode.PIPELINE,
    order=["stage1.py", "stage2.py"],
)

report = run_workspace_with_self_repair(task="...", workspace=ws, max_attempts=5)
print(report.ok)              # True only if the whole workspace genuinely ran clean
print(report.final_workspace.as_dict_map())   # the corrected files, if any were fixed
```

**Cross-file self-repair, proven, not assumed:** when `main.py` calls
`helper.py` and `helper.py` has the actual bug, Python's traceback reports
the crash in `main.py` (that's just how tracebacks work) — but the fix
needs to land in `helper.py`. The repair loop sends the **entire file set**
to the LLM along with the real error, and accepts back a JSON object of
`{path: corrected_content}` for however many files actually need to
change — one file, the other file, or both. `test_workspace_repair.py`
verifies exactly this scenario end to end, plus a case where the correct
fix spans two files at once, plus self-repair inside a real pipeline.

## Quick start (single-file)

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# or: export OPENAI_API_KEY=sk-...
```

```python
from codegen_loop import run_codegen_with_self_repair

report = run_codegen_with_self_repair(
    task="Read a CSV-like list of numbers and compute mean/median/stddev.",
    max_attempts=5,
)

print(report.ok)              # True only if it genuinely ran successfully
print(report.summary())
print(report.final_code)
print(report.final_result.stdout)
```

## What changed vs. the old code, concretely

**Before:** `execute_code_plan` returned `{"ok": True, "code": code}` whether
or not anything ran. `extract_execution_trace` checked `has_code` — a string
existing, not a program succeeding. Multi-file projects weren't supported
at all, and the first pass of this rebuild still only let self-repair
rewrite a single file, even when the real bug lived elsewhere in a project.

**Now:** `execute_code_plan` calls `run_codegen_with_self_repair` (single
file) or `run_workspace_with_self_repair` (multi-file), which call
`safe_execution.run_python`, which actually `subprocess.run()`s the code
with real OS-level resource limits and parses the real exit code, stdout,
stderr, and traceback. `ok=True` is load-bearing — it means "exit code 0,
no traceback, didn't time out, didn't hit a resource limit," for every
file that needed to succeed. On failure, the exact traceback is fed back,
and for multi-file workspaces the LLM sees every file and can correct
whichever one(s) actually need it — not just the one that happened to
crash.

## Honest limits — read this before you trust it with untrusted input

- **This is process-level isolation, not a hardened multi-tenant sandbox.**
  `RLIMIT_AS`/`RLIMIT_CPU`/`RLIMIT_FSIZE`/`RLIMIT_NOFILE` plus a wall-clock
  timeout plus an AST-level import allowlist is real containment for "an
  agent fixing its own generated code on a machine you control." It is
  **not** equivalent to gVisor, Firecracker, or a Docker/VM boundary. If
  you ever run code from untrusted third parties (not your own agent),
  put this behind an actual container or VM too.
- **The import allowlist is static analysis, not a guarantee.** It catches
  `import os` and `exec()`/`eval()` tricks at parse time, and now correctly
  distinguishes "this is a sibling file in your own workspace" from "this
  is an unknown third-party package." It does not catch every conceivable
  bytecode-level escape. Treat it as defense-in-depth on top of the
  resource limits, not the only wall.
- **`allow_network=False` in `ResourceLimits` is currently informational
  only** — true network denial needs a network namespace or firewall rule
  outside what pure Python/`resource` can enforce. Left honestly labeled
  in the code rather than pretending it blocks network access.
- **Only Python is wired to real execution** (confirmed this is all you
  need). Adding a second language is mechanical — write a `run_<lang>()`
  mirroring `run_python()`'s subprocess + resource-limit pattern — but
  isn't built here since it's out of scope for what you asked.
- **Document ingestion (PDF/Excel/CSV/HTML → solve()) is a separate,
  still-open gap** flagged in the original assessment and not part of this
  delivery. Happy to build it next if you want it.

## Tuning

- `max_attempts` — default 5, in both `run_codegen_with_self_repair` and
  `run_workspace_with_self_repair`.
- `ResourceLimits(timeout_seconds=..., max_memory_mb=..., max_cpu_seconds=...)`
  — pass your own via `limits=`.
- `DEFAULT_IMPORT_ALLOWLIST` in `safe_execution.py` — edit to add/remove
  permitted third-party packages (numpy/pandas/etc only work if actually
  installed in your execution environment; missing packages just fail
  normally, they're not specially handled). Sibling files inside a
  workspace never need to be added here — they're recognized automatically.

