"""
codegen_loop.py
================
This is what `execute_code_plan` should have been doing all along:

  generate -> run for real -> if it fails, feed the traceback back to the
  LLM -> regenerate -> run again -> repeat up to max_attempts -> return
  honest success/failure with the full attempt history.

No step here can report ok=True unless safe_execution.run_python actually
returned ok=True. There is no stub fallback that masquerades as success.
"""

from __future__ import annotations

import dataclasses
import textwrap
from typing import Any, Dict, List, Optional

from safe_execution import (
    DEFAULT_IMPORT_ALLOWLIST,
    ExecutionResult,
    ResourceLimits,
    run_python,
)
from llm_providers import LLMProvider, get_default_provider


SYSTEM_PROMPT = textwrap.dedent("""\
    You are a careful Python code generator. You write a single, complete,
    runnable Python script that accomplishes the user's task.

    Rules:
    - Output ONLY a python code block (```python ... ```). No prose before
      or after the block.
    - The script must run standalone via `python script.py`.
    - Only use these importable modules: {allowlist}
    - Do not use exec, eval, __import__, or compile.
    - Do not attempt file or network access outside the working directory.
    - If you are given a previous attempt and an error, fix the root cause
      shown in the traceback — do not just wrap it in try/except.
""")

FIX_PROMPT_TEMPLATE = textwrap.dedent("""\
    Task: {task}

    Your previous attempt (attempt #{attempt_num}) failed.

    --- previous code ---
    {previous_code}
    --- end previous code ---

    --- error / traceback ---
    {error}
    --- end error ---

    Write a corrected, complete, standalone script that fixes this. Output
    only the corrected python code block.
""")

INITIAL_PROMPT_TEMPLATE = textwrap.dedent("""\
    Task: {task}

    Write a complete, standalone Python script that accomplishes this task.
    Output only the python code block.
""")


@dataclasses.dataclass
class Attempt:
    attempt_number: int
    code: str
    result: ExecutionResult

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attempt_number": self.attempt_number,
            "code": self.code,
            "result": self.result.to_dict(),
        }


@dataclasses.dataclass
class CodegenRunReport:
    """The honest replacement for the old fake `{"ok": True, "code": ...}`
    return value. `ok` here means the code genuinely ran successfully."""
    ok: bool
    task: str
    attempts: List[Attempt]
    final_code: Optional[str]
    final_result: Optional[ExecutionResult]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "task": self.task,
            "num_attempts": len(self.attempts),
            "attempts": [a.to_dict() for a in self.attempts],
            "final_code": self.final_code,
            "final_result": self.final_result.to_dict() if self.final_result else None,
        }

    def summary(self) -> str:
        if self.ok:
            return (
                f"Succeeded after {len(self.attempts)} attempt(s). "
                f"Runtime: {self.final_result.wall_time_seconds:.2f}s."
            )
        last = self.attempts[-1].result if self.attempts else None
        reason = last.error_summary if last else "no attempts were made"
        return f"Failed after {len(self.attempts)} attempt(s). Last error: {reason}"


def _extract_code_block(text: str) -> str:
    """Pull the first ```python ... ``` (or bare ``` ... ```) block out of
    an LLM response. Falls back to the raw text if no fence is found, since
    some models occasionally forget the fence."""
    markers = ["```python", "```py", "```"]
    for marker in markers:
        if marker in text:
            start = text.index(marker) + len(marker)
            end = text.find("```", start)
            if end != -1:
                return text[start:end].strip()
    return text.strip()


def run_codegen_with_self_repair(
    task: str,
    *,
    provider: Optional[LLMProvider] = None,
    max_attempts: int = 5,
    limits: Optional[ResourceLimits] = None,
    import_allowlist=DEFAULT_IMPORT_ALLOWLIST,
    extra_files: Optional[Dict[str, str]] = None,
    cli_args=None,
    seed_code: Optional[str] = None,
) -> CodegenRunReport:
    """
    The real replacement for execute_code_plan.

    Parameters
    ----------
    task: natural-language description of what the code should do
    provider: an LLMProvider (Anthropic/OpenAI/custom). Defaults to
              whichever API key is in the environment.
    max_attempts: hard cap on generate-run-fix cycles (default 5 — the
                  "most powerful" tier you asked for; raise it if you want
                  more persistence, but each attempt costs an LLM call)
    limits: ResourceLimits for the sandbox (timeout, memory, CPU, etc.)
    import_allowlist: modules the generated code is permitted to import
    extra_files: optional pre-existing files (e.g. input data) placed in
                 the same scratch directory the generated code runs in
    cli_args: argv to pass to the generated script
    seed_code: skip the first LLM call and try this code first (useful if
               you already have a draft and just want it run + auto-fixed)

    Returns
    -------
    CodegenRunReport — ok is True only if code genuinely executed cleanly.
    """
    provider = provider or get_default_provider()
    attempts: List[Attempt] = []

    if seed_code is not None:
        code = seed_code
    else:
        prompt = INITIAL_PROMPT_TEMPLATE.format(task=task)
        response = provider.complete(
            system=SYSTEM_PROMPT.format(allowlist=", ".join(sorted(import_allowlist))),
            user=prompt,
        )
        code = _extract_code_block(response)

    for attempt_num in range(1, max_attempts + 1):
        result = run_python(
            code,
            limits=limits,
            import_allowlist=import_allowlist,
            extra_files=extra_files,
            cli_args=cli_args,
        )
        attempts.append(Attempt(attempt_number=attempt_num, code=code, result=result))

        if result.ok:
            return CodegenRunReport(
                ok=True,
                task=task,
                attempts=attempts,
                final_code=code,
                final_result=result,
            )

        if attempt_num == max_attempts:
            break

        fix_prompt = FIX_PROMPT_TEMPLATE.format(
            task=task,
            attempt_num=attempt_num,
            previous_code=code,
            error=result.error_summary,
        )
        response = provider.complete(
            system=SYSTEM_PROMPT.format(allowlist=", ".join(sorted(import_allowlist))),
            user=fix_prompt,
        )
        code = _extract_code_block(response)

    return CodegenRunReport(
        ok=False,
        task=task,
        attempts=attempts,
        final_code=attempts[-1].code if attempts else None,
        final_result=attempts[-1].result if attempts else None,
    )
