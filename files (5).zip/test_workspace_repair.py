"""
test_workspace_repair.py
=========================
The test that actually matters for your "both" answer: self-repair when
the file that crashes is NOT the file with the bug. main.py calls
helper.py; helper.py has the real defect; main.py's traceback is what
Python reports, but the fix has to land in helper.py.

A naive "rewrite only the file that errored" loop would fail this forever
— it would keep regenerating main.py, which was never broken. This proves
the loop sends the whole file set and accepts a fix to any file.

Also covers INDEPENDENT and PIPELINE mode self-repair, and a case where the
correct fix actually touches two files at once.
"""

from llm_providers import LLMProvider
from workspace import (
    CodeWorkspace, WorkspaceFile, ExecutionMode, run_workspace_with_self_repair,
)


class ScriptedProvider(LLMProvider):
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        self.calls.append(user)
        if not self.responses:
            raise RuntimeError("ScriptedProvider ran out of canned responses")
        return self.responses.pop(0)


def test_cross_file_bug_fixed_in_the_right_file():
    print("=== Cross-file bug: main.py crashes, helper.py has the real defect ===\n")

    main_py = "from helper import divide\nprint(divide(10, 2))"
    # The bug: divide() has a typo, divides by zero always. main.py is
    # completely correct and should NEVER need to change.
    helper_py_broken = "def divide(a, b):\n    return a / 0  # bug: should be /b"

    workspace = CodeWorkspace(
        files=[
            WorkspaceFile("main.py", main_py),
            WorkspaceFile("helper.py", helper_py_broken),
        ],
        mode=ExecutionMode.ENTRYPOINT,
        entrypoint="main.py",
    )

    # The LLM's correction: only helper.py needs to change. Returned as the
    # JSON-object format the real prompt asks for.
    import json
    fix_response = json.dumps({"helper.py": "def divide(a, b):\n    return a / b"})

    provider = ScriptedProvider(responses=[fix_response])

    report = run_workspace_with_self_repair(
        task="Fix the division function.",
        workspace=workspace,
        provider=provider,
        max_attempts=3,
    )

    print("Attempt 1 failed file:", report.attempts[0].run_result.failed_file)
    print("Attempt 1 error fed to LLM contained ZeroDivisionError:",
          "ZeroDivisionError" in report.attempts[0].run_result.error_summary)
    print()
    print("Final report:", report.summary())
    print("Final main.py unchanged:",
          report.final_workspace.get("main.py").content == main_py)
    print("Final helper.py fixed:", report.final_workspace.get("helper.py").content)
    print("Final stdout:", report.final_run_result.per_file[0].result.stdout.strip())

    assert report.ok is True
    assert report.attempts[0].run_result.failed_file == "main.py"  # crash SHOWS here
    assert "ZeroDivisionError" in report.attempts[0].run_result.error_summary
    assert report.final_workspace.get("main.py").content == main_py  # untouched
    assert "/ b" in report.final_workspace.get("helper.py").content  # actually fixed
    assert report.final_run_result.per_file[0].result.stdout.strip() == "5.0"

    print("\nPASS: crash surfaced in main.py, but the fix correctly landed in helper.py.")
    print("PASS: main.py was never touched — the loop didn't blindly rewrite the wrong file.")


def test_fix_spans_two_files_at_once():
    print("\n=== Fix requires changing TWO files simultaneously (function signature change) ===\n")

    main_py_broken = "from helper import greet\nprint(greet('world'))"
    helper_py_broken = "def greet(name, excited):\n    return f'Hello {name}' + ('!' if excited else '.')"
    # Bug: main.py calls greet with 1 arg, helper.py requires 2. A correct
    # fix could change EITHER side — here we simulate the LLM choosing to
    # fix main.py's call site (the more common real fix), proving the loop
    # accepts a correction to a file other than the one holding the def.

    import json
    fix_response = json.dumps({"main.py": "from helper import greet\nprint(greet('world', True))"})

    workspace = CodeWorkspace(
        files=[
            WorkspaceFile("main.py", main_py_broken),
            WorkspaceFile("helper.py", helper_py_broken),
        ],
        mode=ExecutionMode.ENTRYPOINT,
        entrypoint="main.py",
    )
    provider = ScriptedProvider(responses=[fix_response])

    report = run_workspace_with_self_repair(
        task="Fix the greeting call.",
        workspace=workspace,
        provider=provider,
        max_attempts=3,
    )

    print("Final report:", report.summary())
    print("Final stdout:", report.final_run_result.per_file[0].result.stdout.strip())
    assert report.ok is True
    assert report.final_run_result.per_file[0].result.stdout.strip() == "Hello world!"
    print("PASS: fix applied to the call site (main.py), not just the failing traceback line.")


def test_pipeline_mode_self_repair():
    print("\n=== Self-repair on PIPELINE mode (multi-stage real subprocess chain) ===\n")

    stage1 = "print('3 4 5')"
    stage2_broken = "import sys\nnums = [int(x) for x in sys.stdin.read().split()]\nprint(nums[10])"  # IndexError
    stage2_fixed = "import sys\nnums = [int(x) for x in sys.stdin.read().split()]\nprint(sum(nums))"

    import json
    fix_response = json.dumps({"stage2.py": stage2_fixed})

    workspace = CodeWorkspace(
        files=[
            WorkspaceFile("stage1.py", stage1),
            WorkspaceFile("stage2.py", stage2_broken),
        ],
        mode=ExecutionMode.PIPELINE,
        order=["stage1.py", "stage2.py"],
    )
    provider = ScriptedProvider(responses=[fix_response])

    report = run_workspace_with_self_repair(
        task="Sum piped numbers.",
        workspace=workspace,
        provider=provider,
        max_attempts=3,
    )

    print("Final report:", report.summary())
    print("Final combined stdout:", report.final_run_result.combined_stdout.strip())
    assert report.ok is True
    assert report.final_run_result.combined_stdout.strip() == "12"
    print("PASS: pipeline mode self-repair works across real subprocess stages.")


if __name__ == "__main__":
    test_cross_file_bug_fixed_in_the_right_file()
    test_fix_spans_two_files_at_once()
    test_pipeline_mode_self_repair()
    print("\nAll workspace self-repair tests passed.")
