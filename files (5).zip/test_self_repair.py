"""
test_self_repair.py
====================
Proves the generate -> run -> fail -> feed traceback back -> fix -> run ->
succeed loop actually works mechanically, without needing a live API key.

Uses a ScriptedProvider that returns a sequence of canned responses,
simulating what a real LLM does: see the error, fix the bug. This isolates
"does the orchestration logic work" from "is network access available in
this sandbox" (it isn't, here — no ANTHROPIC_API_KEY in this container).

Run this file directly to see it work. When you deploy with a real
ANTHROPIC_API_KEY or OPENAI_API_KEY set, swap ScriptedProvider for
get_default_provider() and the exact same loop calls a real model.
"""

from llm_providers import LLMProvider
from codegen_loop import run_codegen_with_self_repair


class ScriptedProvider(LLMProvider):
    """Returns pre-written responses in order — stands in for a real LLM
    so we can test the retry loop deterministically."""

    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        self.calls.append(user)
        if not self.responses:
            raise RuntimeError("ScriptedProvider ran out of canned responses")
        return self.responses.pop(0)


def test_self_repair_fixes_a_real_bug():
    print("=== Self-repair loop: broken code -> real traceback -> fixed code -> success ===\n")

    # Attempt 1: deliberately broken (off-by-one causes IndexError)
    broken = """\
```python
data = [1, 2, 3, 4, 5]
total = 0
for i in range(len(data) + 1):
    total += data[i]
print("sum:", total)
```"""

    # Attempt 2: the "fix" a real LLM would produce after seeing the
    # IndexError traceback — corrects the off-by-one.
    fixed = """\
```python
data = [1, 2, 3, 4, 5]
total = 0
for i in range(len(data)):
    total += data[i]
print("sum:", total)
```"""

    provider = ScriptedProvider(responses=[broken, fixed])

    report = run_codegen_with_self_repair(
        task="Sum a list of 5 integers and print the total.",
        provider=provider,
        max_attempts=5,
    )

    print(f"Attempt 1 code ran -> ok={report.attempts[0].result.ok}")
    print(f"Attempt 1 traceback (fed back to LLM as fix prompt):")
    print(report.attempts[0].result.traceback)
    print()
    print(f"Attempt 2 code ran -> ok={report.attempts[1].result.ok}")
    print(f"Attempt 2 stdout: {report.attempts[1].result.stdout!r}")
    print()
    print("Final report:", report.summary())
    print()

    # Verify the traceback was actually included in the prompt sent for the fix
    fix_prompt_sent = provider.calls[1]
    assert "IndexError" in fix_prompt_sent, "traceback was not fed back into the fix prompt!"
    assert report.ok is True, "self-repair should have succeeded on attempt 2"
    assert len(report.attempts) == 2, "should have stopped after success, not burned all 5 attempts"
    assert "sum: 15" in report.attempts[1].result.stdout

    print("PASS: traceback was genuinely fed back into the regeneration prompt.")
    print("PASS: loop stopped immediately on first real success (didn't waste attempts).")
    print("PASS: final stdout matches expected correct output (sum: 15).")


def test_honest_failure_when_unfixable():
    print("\n=== Self-repair loop: code that never gets fixed -> honest failure, no fake ok ===\n")

    always_broken = "```python\nraise ValueError('this will never work')\n```"
    provider = ScriptedProvider(responses=[always_broken] * 4)  # initial + 3 fix attempts

    report = run_codegen_with_self_repair(
        task="Do something impossible.",
        provider=provider,
        max_attempts=4,
    )

    print("Final report:", report.summary())
    assert report.ok is False, "should NOT report ok=True for code that never runs successfully"
    assert len(report.attempts) == 4, "should use all available attempts before giving up"
    for a in report.attempts:
        assert a.result.ok is False

    print("PASS: report.ok is False — no fake success returned.")
    print("PASS: all 4 attempts genuinely executed and genuinely failed.")


def test_static_safety_blocks_dangerous_code():
    print("\n=== Static safety check blocks dangerous imports before any process runs ===\n")

    dangerous = "```python\nimport subprocess\nsubprocess.run(['rm', '-rf', '/'])\n```"
    provider = ScriptedProvider(responses=[dangerous])

    report = run_codegen_with_self_repair(
        task="malicious task",
        provider=provider,
        max_attempts=1,
    )

    assert report.ok is False
    assert report.final_result.static_check_error is not None
    print("Blocked with:", report.final_result.static_check_error)
    print("PASS: dangerous code never reached subprocess.run — caught at parse time.")


if __name__ == "__main__":
    test_self_repair_fixes_a_real_bug()
    test_honest_failure_when_unfixable()
    test_static_safety_blocks_dangerous_code()
    print("\nAll tests passed.")
