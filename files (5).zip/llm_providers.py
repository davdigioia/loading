"""
llm_providers.py
=================
A small, swappable interface so codegen_loop.py doesn't care which LLM API
is generating/fixing code. Ship with an Anthropic implementation; add
OpenAI, local models, whatever — same interface.

Only stdlib + `requests` if available; falls back to urllib so this has
zero hard dependencies.
"""

from __future__ import annotations

import abc
import json
import os
import urllib.request
import urllib.error
from typing import Optional


class LLMProvider(abc.ABC):
    """Implement `complete` and you can plug into the codegen retry loop."""

    @abc.abstractmethod
    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        """Return the model's text response to a single-turn prompt."""
        raise NotImplementedError


def _http_post_json(url: str, headers: dict, payload: dict, timeout: float = 60.0) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} from {url}: {body}") from e


class AnthropicProvider(LLMProvider):
    """
    Calls the Anthropic /v1/messages endpoint directly.
    Set ANTHROPIC_API_KEY in the environment, or pass api_key explicitly.
    """

    def __init__(self, api_key: Optional[str] = None, model: str = "claude-sonnet-4-6"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "No Anthropic API key found. Set ANTHROPIC_API_KEY or pass api_key=."
            )
        self.model = model

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        resp = _http_post_json(
            "https://api.anthropic.com/v1/messages",
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            },
            payload={
                "model": self.model,
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": "user", "content": user}],
            },
        )
        blocks = resp.get("content", [])
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        return text


class OpenAIProvider(LLMProvider):
    """
    Calls the OpenAI /v1/chat/completions endpoint.
    Set OPENAI_API_KEY in the environment, or pass api_key explicitly.
    """

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o"):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "No OpenAI API key found. Set OPENAI_API_KEY or pass api_key=."
            )
        self.model = model

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        resp = _http_post_json(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            payload={
                "model": self.model,
                "max_tokens": max_tokens,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            },
        )
        return resp["choices"][0]["message"]["content"]


class GenericOpenAICompatProvider(LLMProvider):
    """
    For any OpenAI-compatible endpoint: local servers (vLLM, llama.cpp,
    Ollama's OpenAI-compat route, LM Studio), Mistral, Groq, etc.
    Just point base_url at the right host.
    """

    def __init__(self, base_url: str, api_key: Optional[str] = None, model: str = "default"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or ""
        self.model = model

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        resp = _http_post_json(
            f"{self.base_url}/chat/completions",
            headers=headers,
            payload={
                "model": self.model,
                "max_tokens": max_tokens,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            },
        )
        return resp["choices"][0]["message"]["content"]


class StaticStubProvider(LLMProvider):
    """No network calls. Useful for tests, or as the existing
    `_fallback_code` behavior, but now it's explicit and labeled instead of
    silently masquerading as a real generation."""

    def __init__(self, canned_response: str = "# no LLM provider configured\npass\n"):
        self.canned_response = canned_response

    def complete(self, system: str, user: str, *, max_tokens: int = 2000) -> str:
        return self.canned_response


def get_default_provider() -> LLMProvider:
    """
    Picks a provider based on whatever API key is present in the
    environment. Order: Anthropic, then OpenAI, then stub (with a loud
    warning, not a silent fake-success).
    """
    if os.environ.get("ANTHROPIC_API_KEY"):
        return AnthropicProvider()
    if os.environ.get("OPENAI_API_KEY"):
        return OpenAIProvider()
    import warnings
    warnings.warn(
        "No ANTHROPIC_API_KEY or OPENAI_API_KEY found in environment. "
        "Falling back to StaticStubProvider — codegen will NOT actually "
        "generate or fix real code until you configure a provider.",
        RuntimeWarning,
    )
    return StaticStubProvider()
